---
tags: [legal]
---
# Health and Safety Duties

Health and Safety Duties belongs to the [[Legal Suite]] and is about contracts and compliance. Ask what a first-time customer would expect, then make that easy. Related: [[Partnership Agreement]], [[Intellectual Property Audit]].
