---
tags: [legal]
---
# Employment Agreement Basics

Employment Agreement Basics belongs to the [[Legal Suite]] and is about contracts and compliance. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Trade Licence Renewal]], [[Non-disclosure Agreement]].
