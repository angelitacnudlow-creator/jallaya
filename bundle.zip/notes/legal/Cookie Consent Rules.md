---
tags: [legal]
---
# Cookie Consent Rules

Cookie Consent Rules belongs to the [[Legal Suite]] and is about contracts and compliance. Start small, write down what you did, and review it once a week. Related: [[Record Retention Periods]], [[Supplier Contract Checklist]].
