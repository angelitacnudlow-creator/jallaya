---
tags: [legal]
---
# Data Protection Duties

Data Protection Duties belongs to the [[Legal Suite]] and is about contracts and compliance. Do the cheapest test first before spending real money. Related: [[Consumer Rights Summary]], [[Freelancer Contract]].
