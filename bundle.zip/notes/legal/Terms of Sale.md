---
tags: [legal]
---
# Terms of Sale

Terms of Sale belongs to the [[Legal Suite]] and is about contracts and compliance. Do the cheapest test first before spending real money. Related: [[Refund and Returns Law]], [[Consumer Rights Summary]].
