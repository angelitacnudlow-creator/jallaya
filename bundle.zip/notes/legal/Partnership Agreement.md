---
tags: [legal]
---
# Partnership Agreement

Partnership Agreement belongs to the [[Legal Suite]] and is about contracts and compliance. Do the cheapest test first before spending real money. Related: [[Freelancer Contract]], [[Complaint Handling Procedure]].
