---
tags: [legal]
---
# Freelancer Contract

Freelancer Contract belongs to the [[Legal Suite]] and is about contracts and compliance. Delegate the routine part and keep the decision for yourself. Related: [[Cookie Consent Rules]], [[Legal Notice Template]].
