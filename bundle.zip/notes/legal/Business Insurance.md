---
tags: [legal]
---
# Business Insurance

Business Insurance belongs to the [[Legal Suite]] and is about contracts and compliance. Measure the result with a single number and compare it month to month. Related: [[Health and Safety Duties]], [[Business Registration Steps]].
