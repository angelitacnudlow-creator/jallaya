---
tags: [legal]
---
# Non-disclosure Agreement

Non-disclosure Agreement belongs to the [[Legal Suite]] and is about contracts and compliance. Measure the result with a single number and compare it month to month. Related: [[Lease Agreement Review]], [[Health and Safety Duties]].
