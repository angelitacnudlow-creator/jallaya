---
tags: [legal, hub]
---
# Legal Suite

The hub for contracts and compliance. Topics: [[Supplier Contract Checklist]], [[Employment Agreement Basics]], [[Trade Licence Renewal]], [[Privacy Policy Outline]], [[Terms of Sale]], [[Refund and Returns Law]], [[Trademark Registration]], [[Copyright for Content]], [[Non-disclosure Agreement]], [[Lease Agreement Review]], [[Data Protection Duties]], [[Consumer Rights Summary]], [[Invoice Legal Requirements]], [[Dispute Resolution Steps]], [[Business Insurance]], [[Health and Safety Duties]], [[Partnership Agreement]], [[Freelancer Contract]], [[Cookie Consent Rules]], [[Record Retention Periods]], [[Debt Collection Letter]], [[Business Registration Steps]], [[Intellectual Property Audit]], [[Complaint Handling Procedure]], [[Legal Notice Template]]
