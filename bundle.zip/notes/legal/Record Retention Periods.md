---
tags: [legal]
---
# Record Retention Periods

Record Retention Periods belongs to the [[Legal Suite]] and is about contracts and compliance. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Debt Collection Letter]], [[Employment Agreement Basics]].
