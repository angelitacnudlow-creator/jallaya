---
tags: [legal]
---
# Consumer Rights Summary

Consumer Rights Summary belongs to the [[Legal Suite]] and is about contracts and compliance. Delegate the routine part and keep the decision for yourself. Related: [[Invoice Legal Requirements]], [[Cookie Consent Rules]].
