---
tags: [legal]
---
# Complaint Handling Procedure

Complaint Handling Procedure belongs to the [[Legal Suite]] and is about contracts and compliance. Delegate the routine part and keep the decision for yourself. Related: [[Legal Notice Template]], [[Refund and Returns Law]].
