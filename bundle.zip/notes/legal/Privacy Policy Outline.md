---
tags: [legal]
---
# Privacy Policy Outline

Privacy Policy Outline belongs to the [[Legal Suite]] and is about contracts and compliance. Ask what a first-time customer would expect, then make that easy. Related: [[Terms of Sale]], [[Data Protection Duties]].
