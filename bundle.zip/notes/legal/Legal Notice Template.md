---
tags: [legal]
---
# Legal Notice Template

Legal Notice Template belongs to the [[Legal Suite]] and is about contracts and compliance. Start small, write down what you did, and review it once a week. Related: [[Supplier Contract Checklist]], [[Trademark Registration]].
