---
tags: [legal]
---
# Intellectual Property Audit

Intellectual Property Audit belongs to the [[Legal Suite]] and is about contracts and compliance. Do the cheapest test first before spending real money. Related: [[Complaint Handling Procedure]], [[Terms of Sale]].
