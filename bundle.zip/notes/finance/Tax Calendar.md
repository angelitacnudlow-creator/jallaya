---
tags: [finance]
---
# Tax Calendar

Tax Calendar belongs to the [[Finance Suite]] and is about cash flow and money habits. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[VAT Basics]], [[Supplier Payment Terms]].
