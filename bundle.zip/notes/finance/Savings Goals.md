---
tags: [finance]
---
# Savings Goals

Savings Goals belongs to the [[Finance Suite]] and is about cash flow and money habits. Do the cheapest test first before spending real money. Related: [[Quarterly Financial Review]], [[Cost of Goods Sold]].
