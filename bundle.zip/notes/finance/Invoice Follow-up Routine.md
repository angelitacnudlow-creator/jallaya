---
tags: [finance]
---
# Invoice Follow-up Routine

Invoice Follow-up Routine belongs to the [[Finance Suite]] and is about cash flow and money habits. Do the cheapest test first before spending real money. Related: [[Late Payment Policy]], [[Bank Reconciliation]].
