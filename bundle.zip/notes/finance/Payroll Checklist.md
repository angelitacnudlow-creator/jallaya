---
tags: [finance]
---
# Payroll Checklist

Payroll Checklist belongs to the [[Finance Suite]] and is about cash flow and money habits. Ask what a first-time customer would expect, then make that easy. Related: [[Petty Cash Rules]], [[Savings Goals]].
