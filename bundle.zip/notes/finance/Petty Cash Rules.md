---
tags: [finance]
---
# Petty Cash Rules

Petty Cash Rules belongs to the [[Finance Suite]] and is about cash flow and money habits. Do the cheapest test first before spending real money. Related: [[Bank Reconciliation]], [[Quarterly Financial Review]].
