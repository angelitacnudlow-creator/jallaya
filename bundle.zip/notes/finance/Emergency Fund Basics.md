---
tags: [finance]
---
# Emergency Fund Basics

Emergency Fund Basics belongs to the [[Finance Suite]] and is about cash flow and money habits. Measure the result with a single number and compare it month to month. Related: [[Profit and Loss Reading]], [[Payroll Checklist]].
