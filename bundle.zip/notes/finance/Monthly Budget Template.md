---
tags: [finance]
---
# Monthly Budget Template

Monthly Budget Template belongs to the [[Finance Suite]] and is about cash flow and money habits. Start small, write down what you did, and review it once a week. Related: [[Cash Flow Forecast]], [[Tax Calendar]].
