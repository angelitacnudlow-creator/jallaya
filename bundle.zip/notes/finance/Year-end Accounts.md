---
tags: [finance]
---
# Year-end Accounts

Year-end Accounts belongs to the [[Finance Suite]] and is about cash flow and money habits. Start small, write down what you did, and review it once a week. Related: [[Monthly Budget Template]], [[Expense Categories]].
