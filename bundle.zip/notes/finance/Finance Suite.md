---
tags: [finance, hub]
---
# Finance Suite

The hub for cash flow and money habits. Topics: [[Monthly Budget Template]], [[Cash Flow Forecast]], [[Emergency Fund Basics]], [[Profit and Loss Reading]], [[Invoice Follow-up Routine]], [[Late Payment Policy]], [[Expense Categories]], [[Tax Calendar]], [[VAT Basics]], [[Payroll Checklist]], [[Petty Cash Rules]], [[Bank Reconciliation]], [[Break-even Calculation]], [[Pricing for Margin]], [[Supplier Payment Terms]], [[Loan Comparison]], [[Savings Goals]], [[Quarterly Financial Review]], [[Receipt Filing System]], [[Currency Exchange Tips]], [[Mobile Banking Safety]], [[Daily Sales Totals]], [[Discount Impact on Profit]], [[Cost of Goods Sold]], [[Year-end Accounts]]
