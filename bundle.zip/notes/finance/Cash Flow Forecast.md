---
tags: [finance]
---
# Cash Flow Forecast

Cash Flow Forecast belongs to the [[Finance Suite]] and is about cash flow and money habits. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Emergency Fund Basics]], [[VAT Basics]].
