---
tags: [finance]
---
# Daily Sales Totals

Daily Sales Totals belongs to the [[Finance Suite]] and is about cash flow and money habits. Ask what a first-time customer would expect, then make that easy. Related: [[Discount Impact on Profit]], [[Profit and Loss Reading]].
