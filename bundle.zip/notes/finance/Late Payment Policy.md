---
tags: [finance]
---
# Late Payment Policy

Late Payment Policy belongs to the [[Finance Suite]] and is about cash flow and money habits. Delegate the routine part and keep the decision for yourself. Related: [[Expense Categories]], [[Break-even Calculation]].
