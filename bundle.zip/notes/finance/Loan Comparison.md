---
tags: [finance]
---
# Loan Comparison

Loan Comparison belongs to the [[Finance Suite]] and is about cash flow and money habits. Ask what a first-time customer would expect, then make that easy. Related: [[Savings Goals]], [[Discount Impact on Profit]].
