---
tags: [finance]
---
# VAT Basics

VAT Basics belongs to the [[Finance Suite]] and is about cash flow and money habits. Measure the result with a single number and compare it month to month. Related: [[Payroll Checklist]], [[Loan Comparison]].
