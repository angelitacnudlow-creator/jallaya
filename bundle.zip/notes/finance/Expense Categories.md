---
tags: [finance]
---
# Expense Categories

Expense Categories belongs to the [[Finance Suite]] and is about cash flow and money habits. Start small, write down what you did, and review it once a week. Related: [[Tax Calendar]], [[Pricing for Margin]].
