---
tags: [finance]
---
# Discount Impact on Profit

Discount Impact on Profit belongs to the [[Finance Suite]] and is about cash flow and money habits. Do the cheapest test first before spending real money. Related: [[Cost of Goods Sold]], [[Invoice Follow-up Routine]].
