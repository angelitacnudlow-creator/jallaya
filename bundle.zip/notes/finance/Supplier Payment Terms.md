---
tags: [finance]
---
# Supplier Payment Terms

Supplier Payment Terms belongs to the [[Finance Suite]] and is about cash flow and money habits. Measure the result with a single number and compare it month to month. Related: [[Loan Comparison]], [[Daily Sales Totals]].
