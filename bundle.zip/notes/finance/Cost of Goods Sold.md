---
tags: [finance]
---
# Cost of Goods Sold

Cost of Goods Sold belongs to the [[Finance Suite]] and is about cash flow and money habits. Delegate the routine part and keep the decision for yourself. Related: [[Year-end Accounts]], [[Late Payment Policy]].
