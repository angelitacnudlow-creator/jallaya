---
tags: [finance]
---
# Profit and Loss Reading

Profit and Loss Reading belongs to the [[Finance Suite]] and is about cash flow and money habits. Ask what a first-time customer would expect, then make that easy. Related: [[Invoice Follow-up Routine]], [[Petty Cash Rules]].
