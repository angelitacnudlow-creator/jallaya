---
tags: [finance]
---
# Receipt Filing System

Receipt Filing System belongs to the [[Finance Suite]] and is about cash flow and money habits. Start small, write down what you did, and review it once a week. Related: [[Currency Exchange Tips]], [[Monthly Budget Template]].
