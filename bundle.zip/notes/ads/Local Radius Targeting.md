---
tags: [ads]
---
# Local Radius Targeting

Local Radius Targeting belongs to the [[Ad Suite]] and is about paid advertising. Do the cheapest test first before spending real money. Related: [[Video Ad Scripts]], [[Influencer Brief]].
