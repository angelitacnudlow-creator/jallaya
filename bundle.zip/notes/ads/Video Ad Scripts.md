---
tags: [ads]
---
# Video Ad Scripts

Video Ad Scripts belongs to the [[Ad Suite]] and is about paid advertising. Delegate the routine part and keep the decision for yourself. Related: [[Carousel Ad Layouts]], [[Boosting Posts vs Ads]].
