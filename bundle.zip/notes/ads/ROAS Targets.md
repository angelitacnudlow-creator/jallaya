---
tags: [ads]
---
# ROAS Targets

ROAS Targets belongs to the [[Ad Suite]] and is about paid advertising. Measure the result with a single number and compare it month to month. Related: [[Seasonal Promotion Ads]], [[Weekly Ad Report]].
