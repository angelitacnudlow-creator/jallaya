---
tags: [ads, hub]
---
# Ad Suite

The hub for paid advertising. Topics: [[Facebook Ads Setup]], [[Google Ads Search Campaigns]], [[Instagram Story Ads]], [[TikTok Ad Basics]], [[YouTube Pre-roll Ads]], [[Retargeting Audiences]], [[Lookalike Audiences]], [[Ad Creative Testing]], [[Headline Formulas]], [[Landing Page Matching]], [[Conversion Tracking]], [[Pixel Installation]], [[Daily Budget Pacing]], [[Cost per Click Benchmarks]], [[ROAS Targets]], [[Seasonal Promotion Ads]], [[Local Radius Targeting]], [[Video Ad Scripts]], [[Carousel Ad Layouts]], [[Negative Keywords]], [[Ad Fatigue Signs]], [[Weekly Ad Report]], [[WhatsApp Click Ads]], [[Influencer Brief]], [[Boosting Posts vs Ads]]
