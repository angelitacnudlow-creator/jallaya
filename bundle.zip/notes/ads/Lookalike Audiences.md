---
tags: [ads]
---
# Lookalike Audiences

Lookalike Audiences belongs to the [[Ad Suite]] and is about paid advertising. Start small, write down what you did, and review it once a week. Related: [[Ad Creative Testing]], [[Cost per Click Benchmarks]].
