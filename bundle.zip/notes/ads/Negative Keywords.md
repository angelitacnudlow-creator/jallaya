---
tags: [ads]
---
# Negative Keywords

Negative Keywords belongs to the [[Ad Suite]] and is about paid advertising. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Ad Fatigue Signs]], [[Google Ads Search Campaigns]].
