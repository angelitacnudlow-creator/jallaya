---
tags: [ads]
---
# Cost per Click Benchmarks

Cost per Click Benchmarks belongs to the [[Ad Suite]] and is about paid advertising. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[ROAS Targets]], [[Ad Fatigue Signs]].
