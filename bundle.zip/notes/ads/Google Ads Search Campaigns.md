---
tags: [ads]
---
# Google Ads Search Campaigns

Google Ads Search Campaigns belongs to the [[Ad Suite]] and is about paid advertising. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Instagram Story Ads]], [[Headline Formulas]].
