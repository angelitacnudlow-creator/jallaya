---
tags: [ads]
---
# Daily Budget Pacing

Daily Budget Pacing belongs to the [[Ad Suite]] and is about paid advertising. Start small, write down what you did, and review it once a week. Related: [[Cost per Click Benchmarks]], [[Negative Keywords]].
