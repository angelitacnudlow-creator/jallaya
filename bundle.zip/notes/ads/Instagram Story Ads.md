---
tags: [ads]
---
# Instagram Story Ads

Instagram Story Ads belongs to the [[Ad Suite]] and is about paid advertising. Measure the result with a single number and compare it month to month. Related: [[TikTok Ad Basics]], [[Landing Page Matching]].
