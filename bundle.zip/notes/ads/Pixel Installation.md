---
tags: [ads]
---
# Pixel Installation

Pixel Installation belongs to the [[Ad Suite]] and is about paid advertising. Delegate the routine part and keep the decision for yourself. Related: [[Daily Budget Pacing]], [[Carousel Ad Layouts]].
