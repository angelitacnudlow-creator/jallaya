---
tags: [ads]
---
# Influencer Brief

Influencer Brief belongs to the [[Ad Suite]] and is about paid advertising. Delegate the routine part and keep the decision for yourself. Related: [[Boosting Posts vs Ads]], [[Retargeting Audiences]].
