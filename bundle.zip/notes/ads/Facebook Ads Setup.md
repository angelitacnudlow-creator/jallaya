---
tags: [ads]
---
# Facebook Ads Setup

Facebook Ads Setup belongs to the [[Ad Suite]] and is about paid advertising. Start small, write down what you did, and review it once a week. Related: [[Google Ads Search Campaigns]], [[Ad Creative Testing]].
