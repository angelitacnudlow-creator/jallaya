---
tags: [ads]
---
# Boosting Posts vs Ads

Boosting Posts vs Ads belongs to the [[Ad Suite]] and is about paid advertising. Start small, write down what you did, and review it once a week. Related: [[Facebook Ads Setup]], [[Lookalike Audiences]].
