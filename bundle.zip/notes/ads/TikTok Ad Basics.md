---
tags: [ads]
---
# TikTok Ad Basics

TikTok Ad Basics belongs to the [[Ad Suite]] and is about paid advertising. Ask what a first-time customer would expect, then make that easy. Related: [[YouTube Pre-roll Ads]], [[Conversion Tracking]].
