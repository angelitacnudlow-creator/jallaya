---
tags: [ads]
---
# Conversion Tracking

Conversion Tracking belongs to the [[Ad Suite]] and is about paid advertising. Do the cheapest test first before spending real money. Related: [[Pixel Installation]], [[Video Ad Scripts]].
