---
tags: [ads]
---
# Retargeting Audiences

Retargeting Audiences belongs to the [[Ad Suite]] and is about paid advertising. Delegate the routine part and keep the decision for yourself. Related: [[Lookalike Audiences]], [[Daily Budget Pacing]].
