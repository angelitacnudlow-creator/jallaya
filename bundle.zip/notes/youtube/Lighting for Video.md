---
tags: [youtube]
---
# Lighting for Video

Lighting for Video belongs to the [[YouTube Channel Suite]] and is about video growth. Ask what a first-time customer would expect, then make that easy. Related: [[Audio Cleanup]], [[Copyright Claims]].
