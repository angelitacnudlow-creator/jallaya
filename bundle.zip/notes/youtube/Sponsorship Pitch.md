---
tags: [youtube]
---
# Sponsorship Pitch

Sponsorship Pitch belongs to the [[YouTube Channel Suite]] and is about video growth. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Equipment Starter Kit]], [[Analytics Weekly Check]].
