---
tags: [youtube]
---
# Script Structure

Script Structure belongs to the [[YouTube Channel Suite]] and is about video growth. Do the cheapest test first before spending real money. Related: [[Retention Graph Reading]], [[Channel Keywords]].
