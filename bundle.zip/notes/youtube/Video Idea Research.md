---
tags: [youtube]
---
# Video Idea Research

Video Idea Research belongs to the [[YouTube Channel Suite]] and is about video growth. Start small, write down what you did, and review it once a week. Related: [[Thumbnail Design Rules]], [[Shorts Strategy]].
