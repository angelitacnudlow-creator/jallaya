---
tags: [youtube]
---
# Title Formulas

Title Formulas belongs to the [[YouTube Channel Suite]] and is about video growth. Measure the result with a single number and compare it month to month. Related: [[Hook in First Five Seconds]], [[End Screen Setup]].
