---
tags: [youtube]
---
# B-roll Planning

B-roll Planning belongs to the [[YouTube Channel Suite]] and is about video growth. Start small, write down what you did, and review it once a week. Related: [[Collaboration Outreach]], [[Video Idea Research]].
