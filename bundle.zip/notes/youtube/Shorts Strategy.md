---
tags: [youtube]
---
# Shorts Strategy

Shorts Strategy belongs to the [[YouTube Channel Suite]] and is about video growth. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Playlist Organisation]], [[Equipment Starter Kit]].
