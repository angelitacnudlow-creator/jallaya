---
tags: [youtube]
---
# Equipment Starter Kit

Equipment Starter Kit belongs to the [[YouTube Channel Suite]] and is about video growth. Measure the result with a single number and compare it month to month. Related: [[Lighting for Video]], [[Monetisation Requirements]].
