---
tags: [youtube]
---
# Playlist Organisation

Playlist Organisation belongs to the [[YouTube Channel Suite]] and is about video growth. Measure the result with a single number and compare it month to month. Related: [[End Screen Setup]], [[Lighting for Video]].
