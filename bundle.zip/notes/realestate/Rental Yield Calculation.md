---
tags: [realestate]
---
# Rental Yield Calculation

Rental Yield Calculation belongs to the [[Real Estate Suite]] and is about property and premises. Measure the result with a single number and compare it month to month. Related: [[Stamp Duty Notes]], [[Property Photography]].
