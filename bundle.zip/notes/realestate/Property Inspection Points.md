---
tags: [realestate]
---
# Property Inspection Points

Property Inspection Points belongs to the [[Real Estate Suite]] and is about property and premises. Start small, write down what you did, and review it once a week. Related: [[Tenant Screening]], [[Foot Traffic Analysis]].
