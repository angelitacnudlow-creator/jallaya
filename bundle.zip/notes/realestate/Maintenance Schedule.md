---
tags: [realestate]
---
# Maintenance Schedule

Maintenance Schedule belongs to the [[Real Estate Suite]] and is about property and premises. Do the cheapest test first before spending real money. Related: [[Security Deposit Rules]], [[Mortgage Types]].
