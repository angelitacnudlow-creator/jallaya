---
tags: [realestate]
---
# Utility Setup Checklist

Utility Setup Checklist belongs to the [[Real Estate Suite]] and is about property and premises. Ask what a first-time customer would expect, then make that easy. Related: [[Maintenance Schedule]], [[Lease Renewal Timeline]].
