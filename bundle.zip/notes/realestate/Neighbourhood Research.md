---
tags: [realestate]
---
# Neighbourhood Research

Neighbourhood Research belongs to the [[Real Estate Suite]] and is about property and premises. Measure the result with a single number and compare it month to month. Related: [[Utility Setup Checklist]], [[Property Valuation Basics]].
