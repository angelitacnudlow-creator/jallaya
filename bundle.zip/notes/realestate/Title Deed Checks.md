---
tags: [realestate]
---
# Title Deed Checks

Title Deed Checks belongs to the [[Real Estate Suite]] and is about property and premises. Do the cheapest test first before spending real money. Related: [[Renovation Budget]], [[Open House Preparation]].
