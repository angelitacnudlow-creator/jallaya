---
tags: [realestate]
---
# Mortgage Types

Mortgage Types belongs to the [[Real Estate Suite]] and is about property and premises. Do the cheapest test first before spending real money. Related: [[Home Buying Checklist]], [[Renovation Budget]].
