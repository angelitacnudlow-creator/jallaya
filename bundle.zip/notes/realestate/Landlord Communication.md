---
tags: [realestate]
---
# Landlord Communication

Landlord Communication belongs to the [[Real Estate Suite]] and is about property and premises. Measure the result with a single number and compare it month to month. Related: [[Property Photography]], [[Utility Setup Checklist]].
