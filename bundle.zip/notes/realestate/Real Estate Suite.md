---
tags: [realestate, hub]
---
# Real Estate Suite

The hub for property and premises. Topics: [[Shop Location Scouting]], [[Rent Negotiation Tips]], [[Property Valuation Basics]], [[Lease Renewal Timeline]], [[Mortgage Types]], [[Home Buying Checklist]], [[Property Inspection Points]], [[Tenant Screening]], [[Rental Yield Calculation]], [[Stamp Duty Notes]], [[Title Deed Checks]], [[Renovation Budget]], [[Interior Layout for Shops]], [[Foot Traffic Analysis]], [[Landlord Communication]], [[Property Photography]], [[Listing Description Writing]], [[Open House Preparation]], [[Co-working Space Options]], [[Warehouse Storage Planning]], [[Neighbourhood Research]], [[Utility Setup Checklist]], [[Maintenance Schedule]], [[Security Deposit Rules]], [[Moving Day Plan]]
