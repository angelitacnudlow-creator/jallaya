---
tags: [realestate]
---
# Moving Day Plan

Moving Day Plan belongs to the [[Real Estate Suite]] and is about property and premises. Start small, write down what you did, and review it once a week. Related: [[Shop Location Scouting]], [[Property Inspection Points]].
