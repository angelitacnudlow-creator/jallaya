---
tags: [realestate]
---
# Foot Traffic Analysis

Foot Traffic Analysis belongs to the [[Real Estate Suite]] and is about property and premises. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Landlord Communication]], [[Neighbourhood Research]].
