---
tags: [realestate]
---
# Tenant Screening

Tenant Screening belongs to the [[Real Estate Suite]] and is about property and premises. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Rental Yield Calculation]], [[Landlord Communication]].
