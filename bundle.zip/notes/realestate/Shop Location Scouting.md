---
tags: [realestate]
---
# Shop Location Scouting

Shop Location Scouting belongs to the [[Real Estate Suite]] and is about property and premises. Start small, write down what you did, and review it once a week. Related: [[Rent Negotiation Tips]], [[Tenant Screening]].
