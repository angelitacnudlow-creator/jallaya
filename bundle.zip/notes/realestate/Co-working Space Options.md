---
tags: [realestate]
---
# Co-working Space Options

Co-working Space Options belongs to the [[Real Estate Suite]] and is about property and premises. Start small, write down what you did, and review it once a week. Related: [[Warehouse Storage Planning]], [[Shop Location Scouting]].
