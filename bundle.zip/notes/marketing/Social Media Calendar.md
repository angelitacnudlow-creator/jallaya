# Social Media Calendar

Post on Facebook three times a week and on Instagram four times a week. Keep a fixed rhythm: Monday behind-the-scenes in the bakery, Wednesday a product close-up, Friday an offer or a customer story, Sunday a short reel. Plan the whole month on one sheet every last Thursday, and schedule posts in advance so busy days never break the rhythm. Commonly good posting times are 12 to 1pm and 8 to 10pm. Always reply to comments within a few hours.

Related: [[Instagram and Reels Tips]], [[Brand Voice and Content Ideas]], [[Marketing Plan]]
