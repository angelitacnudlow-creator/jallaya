# Customer Loyalty Program

A simple stamp card works: buy ten, get the eleventh free. Give a small birthday treat to anyone who shares their birthday. Offer bring-a-friend rewards where both people get a discount, because word of mouth is the cheapest marketing. Record regular customers in a sheet with name, phone, favourite item, and last visit, and message people who have not visited for a month with a friendly nudge and a small offer.

Related: [[Local SEO and Google Business Profile]], [[Email and WhatsApp Marketing]], [[Customer Feedback]]
