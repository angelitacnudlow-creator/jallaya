# Email and WhatsApp Marketing

Collect phone numbers and emails at the counter with permission, and say what you will send. Send one WhatsApp broadcast a week to the customer list: a short message, one photo, one offer, one clear way to order. Never send more than two messages a week or people will leave. For email, a monthly newsletter with a story, a recipe or tip, and one coupon works best. Keep subject lines under 45 characters. Always include an easy way to stop receiving messages.

Related: [[Customer Loyalty Program]], [[Instagram and Reels Tips]]
