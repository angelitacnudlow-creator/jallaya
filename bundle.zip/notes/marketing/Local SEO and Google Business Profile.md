# Local SEO and Google Business Profile

Claim and fill in the Google Business Profile completely: exact name, address, phone, opening hours, categories, and at least ten good photos. Update holiday hours early, especially for Eid. Ask every happy customer for a Google review and reply to every review, good or bad, politely within two days. Use the same name, address, and phone number everywhere online. Add a post to the profile each week with the current offer. Local searches like bakery near me lead directly to walk-in customers.

Related: [[Ad Budget and Campaign Planning]], [[Customer Loyalty Program]], [[Opening Hours]], [[Customer Feedback]]
