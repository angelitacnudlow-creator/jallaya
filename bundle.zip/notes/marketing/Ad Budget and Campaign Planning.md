# Ad Budget and Campaign Planning

Start small: spend 5 to 10 percent of monthly revenue on marketing and test before scaling. For Facebook and Instagram ads, target a radius of 3 to 5 km around the shop, pick one goal such as messages or store visits, and run two versions of the creative for three days. Keep the better one and stop the other. Measure cost per message or cost per visit, not impressions. Plan seasonal campaigns four to six weeks ahead: Ramadan and Eid, Pohela Boishakh, winter pitha season, and weddings.

Related: [[Brand Voice and Content Ideas]], [[Local SEO and Google Business Profile]], [[Marketing Plan]], [[Pricing Policy]]
