# Instagram and Reels Tips

A good reel is 7 to 15 seconds, filmed vertically in daylight, and the first two seconds must show the finished product, such as steam rising from a fresh loaf. Use a trending sound at low volume, add large on-screen captions because most people watch muted, and end with one call to action: visit, order, or save. A good photo post uses natural light, a clean background, and one hero item. Write the caption in two lines and put three to five relevant hashtags in the first comment. Track saves and shares, not only likes.

Related: [[Email and WhatsApp Marketing]], [[Social Media Calendar]]
