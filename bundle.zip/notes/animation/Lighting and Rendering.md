# Lighting and Rendering

Start with three-point lighting: a bright key light from one side, a softer fill light from the other, and a rim light behind to separate the subject from the background. Use soft large lights for gentle shadows and small lights for hard ones. A dark background with a bright edge looks dramatic, which is why product shots use it. Eevee renders quickly and Cycles gives realistic results but takes longer. Render a small test at low resolution and low samples first, then do the final render at 1920 by 1080 or higher. Use a denoiser to cut render time.

Related: [[Rigging and Character Animation]], [[Keyframes and Easing]]
