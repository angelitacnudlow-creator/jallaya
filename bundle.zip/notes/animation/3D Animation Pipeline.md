# 3D Animation Pipeline

Every 3D animation follows the same stages. First, plan with an idea, a short script, and rough storyboard sketches. Second, model the objects. Third, add materials and textures. Fourth, rig anything that must bend or move, such as a character. Fifth, animate with keyframes. Sixth, set up lights and a camera. Seventh, render the frames. Eighth, edit, add sound, and export a video. Work from rough to fine: block the big movements first, then refine the timing, then polish details. Save often and keep versions.

Related: [[Blender Basics]], [[Turntable and Product Animation]]
