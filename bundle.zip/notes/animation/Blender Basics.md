# Blender Basics

Blender is free and does modelling, animation, and rendering. Orbit the view with the middle mouse button, pan with Shift plus middle mouse, and zoom with the scroll wheel. Press G to move, R to rotate, S to scale, and X, Y, or Z to lock an axis. Tab switches between object mode and edit mode. Shift plus A adds a new object, and Ctrl+Z undoes. Use the Timeline at the bottom for animation, and press I over a value to insert a keyframe. Save with Ctrl+S and turn on auto save.

Related: [[Keyframes and Easing]], [[3D Animation Pipeline]]
