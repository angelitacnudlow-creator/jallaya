# Turntable and Product Animation

A turntable is the classic product animation: the object rotates a full 360 degrees on a base while the camera stays still. Use a loop of 120 to 240 frames with linear interpolation so the speed never changes, and make the last frame match the first to loop perfectly. Light with a large soft box overhead and a rim light, on a dark reflective floor. Add a slow camera drift for a premium feel. In Allaya's workshop, ask for a model and say take it apart to see an exploded view, which is also a useful product animation.

Related: [[3D Animation Pipeline]], [[Rigging and Character Animation]], [[Lighting and Rendering]]
