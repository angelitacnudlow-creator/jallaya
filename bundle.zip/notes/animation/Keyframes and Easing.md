# Keyframes and Easing

A keyframe records a value, such as position, rotation, or scale, at a specific frame, and the software fills in the frames between. Set the start and end poses first, then add breakdown poses in the middle. Easing controls speed: ease in and out makes movement start and stop gently and feels natural, while linear movement looks robotic. Use the Graph Editor to adjust curves. Twelve frames per second feels snappy and 24 is standard film. Add anticipation before a big move and overshoot after it to make motion feel alive.

Related: [[Lighting and Rendering]], [[Blender Basics]]
