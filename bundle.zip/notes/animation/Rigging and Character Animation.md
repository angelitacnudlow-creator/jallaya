# Rigging and Character Animation

A rig is a skeleton of bones that lets you pose a model. Place bones inside the model, parent them in a chain, and bind the mesh to the bones with weight painting. Add inverse kinematics to feet and hands so they stay planted while the body moves. Animate with poses: contact, down, passing, and up make a walk cycle. A cycle should loop with the last frame matching the first. Start with a simple bouncing ball before moving on to characters, because it teaches timing, weight, and squash and stretch.

Related: [[Turntable and Product Animation]], [[Lighting and Rendering]]
