---
tags: [seo]
---
# Mobile Friendliness

Mobile Friendliness belongs to the [[SEO Suite]] and is about search visibility. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Schema Markup Guide]], [[Long-tail Keywords]].
