---
tags: [seo]
---
# Schema Markup Guide

Schema Markup Guide belongs to the [[SEO Suite]] and is about search visibility. Measure the result with a single number and compare it month to month. Related: [[XML Sitemap]], [[Competitor Gap Analysis]].
