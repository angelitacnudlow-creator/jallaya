---
tags: [seo]
---
# Header Structure

Header Structure belongs to the [[SEO Suite]] and is about search visibility. Ask what a first-time customer would expect, then make that easy. Related: [[Internal Linking Plan]], [[Robots.txt Rules]].
