---
tags: [seo]
---
# Meta Description Tips

Meta Description Tips belongs to the [[SEO Suite]] and is about search visibility. Measure the result with a single number and compare it month to month. Related: [[Header Structure]], [[XML Sitemap]].
