---
tags: [seo]
---
# Robots.txt Rules

Robots.txt Rules belongs to the [[SEO Suite]] and is about search visibility. Do the cheapest test first before spending real money. Related: [[Image Alt Text]], [[Canonical Tags]].
