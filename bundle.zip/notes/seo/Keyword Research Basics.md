---
tags: [seo]
---
# Keyword Research Basics

Keyword Research Basics belongs to the [[SEO Suite]] and is about search visibility. Start small, write down what you did, and review it once a week. Related: [[Title Tag Writing]], [[Mobile Friendliness]].
