---
tags: [seo]
---
# Competitor Gap Analysis

Competitor Gap Analysis belongs to the [[SEO Suite]] and is about search visibility. Ask what a first-time customer would expect, then make that easy. Related: [[Core Web Vitals]], [[Local Citations]].
