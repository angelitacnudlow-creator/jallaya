---
tags: [seo]
---
# Image Alt Text

Image Alt Text belongs to the [[SEO Suite]] and is about search visibility. Delegate the routine part and keep the decision for yourself. Related: [[Content Calendar for SEO]], [[Broken Link Repair]].
