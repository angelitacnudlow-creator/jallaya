---
tags: [seo]
---
# Search Intent Types

Search Intent Types belongs to the [[SEO Suite]] and is about search visibility. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Long-tail Keywords]], [[Blog Post Template]].
