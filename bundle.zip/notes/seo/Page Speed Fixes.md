---
tags: [seo]
---
# Page Speed Fixes

Page Speed Fixes belongs to the [[SEO Suite]] and is about search visibility. Start small, write down what you did, and review it once a week. Related: [[Mobile Friendliness]], [[Search Intent Types]].
