---
tags: [seo]
---
# Long-tail Keywords

Long-tail Keywords belongs to the [[SEO Suite]] and is about search visibility. Measure the result with a single number and compare it month to month. Related: [[Competitor Gap Analysis]], [[FAQ Page Strategy]].
