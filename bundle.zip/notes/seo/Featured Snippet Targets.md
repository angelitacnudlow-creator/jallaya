---
tags: [seo]
---
# Featured Snippet Targets

Featured Snippet Targets belongs to the [[SEO Suite]] and is about search visibility. Delegate the routine part and keep the decision for yourself. Related: [[AI Search Optimisation]], [[Backlink Outreach]].
