---
tags: [seo]
---
# Local Citations

Local Citations belongs to the [[SEO Suite]] and is about search visibility. Do the cheapest test first before spending real money. Related: [[Featured Snippet Targets]], [[Internal Linking Plan]].
