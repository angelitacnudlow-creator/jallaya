---
tags: [seo]
---
# Blog Post Template

Blog Post Template belongs to the [[SEO Suite]] and is about search visibility. Measure the result with a single number and compare it month to month. Related: [[FAQ Page Strategy]], [[Meta Description Tips]].
