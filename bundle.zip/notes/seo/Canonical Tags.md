---
tags: [seo]
---
# Canonical Tags

Canonical Tags belongs to the [[SEO Suite]] and is about search visibility. Delegate the routine part and keep the decision for yourself. Related: [[Broken Link Repair]], [[AI Search Optimisation]].
