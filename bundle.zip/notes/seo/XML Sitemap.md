---
tags: [seo]
---
# XML Sitemap

XML Sitemap belongs to the [[SEO Suite]] and is about search visibility. Ask what a first-time customer would expect, then make that easy. Related: [[Robots.txt Rules]], [[Core Web Vitals]].
