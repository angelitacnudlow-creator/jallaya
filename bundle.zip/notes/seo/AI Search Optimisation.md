---
tags: [seo]
---
# AI Search Optimisation

AI Search Optimisation belongs to the [[SEO Suite]] and is about search visibility. Start small, write down what you did, and review it once a week. Related: [[Keyword Research Basics]], [[Page Speed Fixes]].
