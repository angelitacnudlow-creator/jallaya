---
tags: [seo]
---
# Core Web Vitals

Core Web Vitals belongs to the [[SEO Suite]] and is about search visibility. Do the cheapest test first before spending real money. Related: [[Canonical Tags]], [[Featured Snippet Targets]].
