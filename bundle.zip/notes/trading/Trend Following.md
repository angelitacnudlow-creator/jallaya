---
tags: [trading]
---
# Trend Following

Trend Following belongs to the [[Trading Suite]] and is about markets and risk. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Breakout Setups]], [[Dividend Basics]].
