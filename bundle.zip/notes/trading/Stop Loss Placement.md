---
tags: [trading]
---
# Stop Loss Placement

Stop Loss Placement belongs to the [[Trading Suite]] and is about markets and risk. Measure the result with a single number and compare it month to month. Related: [[Trading Journal]], [[Market Hours Guide]].
