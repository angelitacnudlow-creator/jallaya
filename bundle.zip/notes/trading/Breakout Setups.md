---
tags: [trading]
---
# Breakout Setups

Breakout Setups belongs to the [[Trading Suite]] and is about markets and risk. Measure the result with a single number and compare it month to month. Related: [[Market Hours Guide]], [[Diversification Principles]].
