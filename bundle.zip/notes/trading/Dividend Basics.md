---
tags: [trading]
---
# Dividend Basics

Dividend Basics belongs to the [[Trading Suite]] and is about markets and risk. Measure the result with a single number and compare it month to month. Related: [[Diversification Principles]], [[Broker Comparison]].
