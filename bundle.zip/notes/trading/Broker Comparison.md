---
tags: [trading]
---
# Broker Comparison

Broker Comparison belongs to the [[Trading Suite]] and is about markets and risk. Ask what a first-time customer would expect, then make that easy. Related: [[Order Types]], [[Trading Journal]].
