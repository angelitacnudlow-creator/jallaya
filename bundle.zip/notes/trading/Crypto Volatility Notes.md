---
tags: [trading]
---
# Crypto Volatility Notes

Crypto Volatility Notes belongs to the [[Trading Suite]] and is about markets and risk. Start small, write down what you did, and review it once a week. Related: [[Stock Screening]], [[Leverage Dangers]].
