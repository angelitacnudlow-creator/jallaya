---
tags: [trading]
---
# Stock Screening

Stock Screening belongs to the [[Trading Suite]] and is about markets and risk. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Dividend Basics]], [[Tax on Trading Gains]].
