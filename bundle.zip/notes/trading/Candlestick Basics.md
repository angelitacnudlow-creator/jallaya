---
tags: [trading]
---
# Candlestick Basics

Candlestick Basics belongs to the [[Trading Suite]] and is about markets and risk. Do the cheapest test first before spending real money. Related: [[Support and Resistance]], [[Forex Pairs Overview]].
