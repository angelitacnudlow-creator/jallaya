---
tags: [trading]
---
# News Trading Caution

News Trading Caution belongs to the [[Trading Suite]] and is about markets and risk. Delegate the routine part and keep the decision for yourself. Related: [[Weekly Review Routine]], [[Support and Resistance]].
