---
tags: [trading]
---
# Backtesting Method

Backtesting Method belongs to the [[Trading Suite]] and is about markets and risk. Delegate the routine part and keep the decision for yourself. Related: [[Paper Trading Plan]], [[Weekly Review Routine]].
