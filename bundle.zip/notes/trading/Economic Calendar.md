---
tags: [trading]
---
# Economic Calendar

Economic Calendar belongs to the [[Trading Suite]] and is about markets and risk. Do the cheapest test first before spending real money. Related: [[Forex Pairs Overview]], [[Backtesting Method]].
