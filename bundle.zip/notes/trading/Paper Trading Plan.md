---
tags: [trading]
---
# Paper Trading Plan

Paper Trading Plan belongs to the [[Trading Suite]] and is about markets and risk. Start small, write down what you did, and review it once a week. Related: [[Leverage Dangers]], [[Risk Management Rules]].
