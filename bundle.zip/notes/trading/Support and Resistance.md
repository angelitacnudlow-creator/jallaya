---
tags: [trading]
---
# Support and Resistance

Support and Resistance belongs to the [[Trading Suite]] and is about markets and risk. Delegate the routine part and keep the decision for yourself. Related: [[Moving Averages]], [[Crypto Volatility Notes]].
