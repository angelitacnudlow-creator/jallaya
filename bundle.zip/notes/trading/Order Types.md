---
tags: [trading]
---
# Order Types

Order Types belongs to the [[Trading Suite]] and is about markets and risk. Do the cheapest test first before spending real money. Related: [[News Trading Caution]], [[Candlestick Basics]].
