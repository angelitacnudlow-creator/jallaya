---
tags: [trading]
---
# Moving Averages

Moving Averages belongs to the [[Trading Suite]] and is about markets and risk. Start small, write down what you did, and review it once a week. Related: [[Trend Following]], [[Stock Screening]].
