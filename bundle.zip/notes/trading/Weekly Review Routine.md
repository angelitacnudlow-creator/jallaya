---
tags: [trading]
---
# Weekly Review Routine

Weekly Review Routine belongs to the [[Trading Suite]] and is about markets and risk. Start small, write down what you did, and review it once a week. Related: [[Risk Management Rules]], [[Moving Averages]].
