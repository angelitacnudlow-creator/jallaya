---
tags: [trading]
---
# Trading Journal

Trading Journal belongs to the [[Trading Suite]] and is about markets and risk. Ask what a first-time customer would expect, then make that easy. Related: [[Candlestick Basics]], [[Economic Calendar]].
