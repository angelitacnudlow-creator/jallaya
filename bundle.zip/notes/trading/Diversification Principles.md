---
tags: [trading]
---
# Diversification Principles

Diversification Principles belongs to the [[Trading Suite]] and is about markets and risk. Ask what a first-time customer would expect, then make that easy. Related: [[Emotional Discipline]], [[Order Types]].
