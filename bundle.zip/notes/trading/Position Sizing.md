---
tags: [trading]
---
# Position Sizing

Position Sizing belongs to the [[Trading Suite]] and is about markets and risk. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Stop Loss Placement]], [[Breakout Setups]].
