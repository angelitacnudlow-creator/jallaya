---
tags: [trading]
---
# Forex Pairs Overview

Forex Pairs Overview belongs to the [[Trading Suite]] and is about markets and risk. Delegate the routine part and keep the decision for yourself. Related: [[Crypto Volatility Notes]], [[Paper Trading Plan]].
