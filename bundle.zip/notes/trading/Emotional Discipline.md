---
tags: [trading]
---
# Emotional Discipline

Emotional Discipline belongs to the [[Trading Suite]] and is about markets and risk. Do the cheapest test first before spending real money. Related: [[Backtesting Method]], [[News Trading Caution]].
