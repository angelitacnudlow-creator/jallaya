---
tags: [reputation]
---
# Testimonial Collection

Testimonial Collection belongs to the [[Reputation Suite]] and is about reviews and trust. Measure the result with a single number and compare it month to month. Related: [[Case Study Template]], [[Press Mention Tracking]].
