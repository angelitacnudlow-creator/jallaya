---
tags: [reputation]
---
# Handling Fake Reviews

Handling Fake Reviews belongs to the [[Reputation Suite]] and is about reviews and trust. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Testimonial Collection]], [[Brand Mention Monitoring]].
