---
tags: [reputation]
---
# Staff Friendliness Training

Staff Friendliness Training belongs to the [[Reputation Suite]] and is about reviews and trust. Keep one simple checklist so nothing is forgotten when you are busy. Related: [[Brand Mention Monitoring]], [[Apology Letter Template]].
