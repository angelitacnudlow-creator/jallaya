---
tags: [reputation]
---
# Trust Badges

Trust Badges belongs to the [[Reputation Suite]] and is about reviews and trust. Do the cheapest test first before spending real money. Related: [[Before and After Photos]], [[Word of Mouth Ideas]].
