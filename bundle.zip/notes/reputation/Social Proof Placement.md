---
tags: [reputation]
---
# Social Proof Placement

Social Proof Placement belongs to the [[Reputation Suite]] and is about reviews and trust. Start small, write down what you did, and review it once a week. Related: [[Review Response Time]], [[Asking for Google Reviews]].
