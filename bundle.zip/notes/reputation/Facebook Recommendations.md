---
tags: [reputation]
---
# Facebook Recommendations

Facebook Recommendations belongs to the [[Reputation Suite]] and is about reviews and trust. Start small, write down what you did, and review it once a week. Related: [[Handling Fake Reviews]], [[Staff Friendliness Training]].
