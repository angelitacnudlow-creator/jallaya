---
tags: [reputation]
---
# Complaint Recovery Script

Complaint Recovery Script belongs to the [[Reputation Suite]] and is about reviews and trust. Start small, write down what you did, and review it once a week. Related: [[Staff Friendliness Training]], [[Review Response Time]].
