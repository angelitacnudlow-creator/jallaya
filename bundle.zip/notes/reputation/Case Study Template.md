---
tags: [reputation]
---
# Case Study Template

Case Study Template belongs to the [[Reputation Suite]] and is about reviews and trust. Ask what a first-time customer would expect, then make that easy. Related: [[Customer Survey Questions]], [[Trust Badges]].
