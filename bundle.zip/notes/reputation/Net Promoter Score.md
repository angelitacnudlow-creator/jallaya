---
tags: [reputation]
---
# Net Promoter Score

Net Promoter Score belongs to the [[Reputation Suite]] and is about reviews and trust. Delegate the routine part and keep the decision for yourself. Related: [[Complaint Recovery Script]], [[Social Proof Placement]].
