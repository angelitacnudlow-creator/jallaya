---
tags: [reputation]
---
# Brand Mention Monitoring

Brand Mention Monitoring belongs to the [[Reputation Suite]] and is about reviews and trust. Measure the result with a single number and compare it month to month. Related: [[Press Mention Tracking]], [[Loyalty Reward Ideas]].
