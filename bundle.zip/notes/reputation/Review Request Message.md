---
tags: [reputation]
---
# Review Request Message

Review Request Message belongs to the [[Reputation Suite]] and is about reviews and trust. Ask what a first-time customer would expect, then make that easy. Related: [[QR Code Review Cards]], [[Customer Survey Questions]].
