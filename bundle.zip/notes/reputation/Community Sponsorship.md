---
tags: [reputation]
---
# Community Sponsorship

Community Sponsorship belongs to the [[Reputation Suite]] and is about reviews and trust. Do the cheapest test first before spending real money. Related: [[Word of Mouth Ideas]], [[QR Code Review Cards]].
