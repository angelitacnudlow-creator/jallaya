---
tags: [reputation]
---
# QR Code Review Cards

QR Code Review Cards belongs to the [[Reputation Suite]] and is about reviews and trust. Do the cheapest test first before spending real money. Related: [[Tripadvisor Profile]], [[Net Promoter Score]].
