# Supplier List

Flour comes from Rahman Mills, delivered every Tuesday. Butter comes from Dairy Fresh, delivered Monday and Thursday. Sugar is ordered monthly from Karim Traders.
