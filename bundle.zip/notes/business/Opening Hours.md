# Opening Hours

Sunrise Bakery opens at 7am and closes at 8pm, Saturday to Thursday. On Friday we open at 9am and close at 6pm. Eid holidays follow a special schedule announced two weeks ahead.
