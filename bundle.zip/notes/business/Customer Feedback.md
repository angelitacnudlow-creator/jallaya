# Customer Feedback

Customers love the cardamom buns. Several asked for gluten free options. The most common complaint is the long queue on Friday mornings.
