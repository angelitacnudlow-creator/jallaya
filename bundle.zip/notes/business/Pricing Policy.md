# Pricing Policy

A sourdough loaf costs 450 taka. A croissant costs 120 taka. Prices are reviewed on the first day of every quarter. Bulk orders above 20 items get a 10 percent discount. See [[Customer Feedback]] before changing prices.
