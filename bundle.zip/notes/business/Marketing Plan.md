# Marketing Plan

We post on Facebook three times a week. The Ramadan campaign starts one month before Ramadan with a pre-order discount. Partner with the cafe on Road 5 for cross promotion.
