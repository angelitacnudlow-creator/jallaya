# GEO

A bridge note connecting areas of the business. See [[SEO Suite]], [[AI Search Optimisation]], [[Local SEO and Google Business Profile]].
