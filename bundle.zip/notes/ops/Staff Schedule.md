# Staff Schedule

The morning shift starts at 5am with two bakers. The counter team of three starts at 6:30am. Nadia manages the afternoon shift. Salaries are paid on the 5th of each month.
