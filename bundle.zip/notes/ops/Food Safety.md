# Food Safety

Fridge temperature must stay below 5 degrees. Record the temperature twice daily in the logbook. Raw egg products are stored on the bottom shelf.
