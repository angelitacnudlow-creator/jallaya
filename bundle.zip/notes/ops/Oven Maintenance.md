# Oven Maintenance

The main deck oven is serviced every six months by Hasan Engineering. The last service was in September. Clean the oven trays every night after closing.
