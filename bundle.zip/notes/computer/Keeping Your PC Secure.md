# Keeping Your PC Secure

Install Windows updates and keep Windows Security turned on. Use a different strong password for every account, store them in a password manager, and turn on two-step verification for email, bank, and social media. Be suspicious of any message that creates urgency or asks for a password, OTP, or payment, and check the sender and link before clicking. Download software only from the official website or the Microsoft Store. Do not use cracked software, which often carries malware. Lock the PC when you step away.

Related: [[Fixing a Slow PC]], [[File Organization and Backups]]
