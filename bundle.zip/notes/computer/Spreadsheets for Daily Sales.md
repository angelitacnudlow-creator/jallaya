# Spreadsheets for Daily Sales

Make one sheet per month with a row per day and columns for date, items sold, cash, card, mobile payments, expenses, and total. Use the SUM formula for totals, and a pivot table to see which items sell best. Add a chart of daily sales to spot slow days. Protect the formulas, keep a backup copy, and enter data at closing time each day. Compare each month with the previous month to decide on stock and offers.

Related: [[Windows Keyboard Shortcuts]], [[Fixing a Slow PC]], [[Pricing Policy]]
