# File Organization and Backups

Keep one main folder for work, with subfolders by year and project, and name files with a date first, like 2026-03-15-invoice-rahim. Never leave files on the desktop. Follow the 3-2-1 backup rule: three copies of important data, on two different kinds of storage, with one copy off-site such as cloud storage. Set a reminder to back up every week and test restoring a file once a month, because a backup you cannot restore is not a backup. Delete old downloads and empty the recycle bin monthly.

Related: [[Keeping Your PC Secure]], [[Windows Keyboard Shortcuts]]
