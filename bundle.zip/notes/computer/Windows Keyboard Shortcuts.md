# Windows Keyboard Shortcuts

Ctrl+C copy, Ctrl+X cut, Ctrl+V paste, Ctrl+Z undo, Ctrl+Y redo, Ctrl+S save, Ctrl+A select all, Ctrl+F find. Alt+Tab switches windows, and Windows key plus D shows the desktop. Windows key plus Shift plus S takes a screenshot of a selected area. Windows key plus V opens clipboard history, and Windows key plus L locks the screen. Ctrl+Shift+Esc opens Task Manager when a program freezes. F2 renames a selected file, and F5 refreshes a window.

Related: [[File Organization and Backups]], [[Spreadsheets for Daily Sales]]
