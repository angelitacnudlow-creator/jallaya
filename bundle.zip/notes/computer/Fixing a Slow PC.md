# Fixing a Slow PC

First restart the computer, since many problems are fixed by a fresh start. Open Task Manager with Ctrl+Shift+Esc and see which program uses the most memory or disk, then close or uninstall it. Disable unneeded startup programs in the Startup tab. Keep at least 15 percent of the drive free, and run Disk Cleanup. Make sure Windows is updated and scan for malware. If the PC still has a mechanical hard drive, replacing it with an SSD is the biggest upgrade. Adding memory to 8 or 16 GB helps if you run many apps at once.

Related: [[Spreadsheets for Daily Sales]], [[Keeping Your PC Secure]]
