/* Allaya: galaxy, chat, bilingual voice, focus controller, workshop client. */
const FINISH_MS = 900;                       // pause window before a spoken sentence is sent (tune after real use)
const MUTE = new URLSearchParams(location.search).get("mute") === "1";
const $ = (id) => document.getElementById(id);
const PALETTE = ["#2f86e0", "#27b46a", "#e0409a", "#e0661f", "#cfd3da", "#2f86e0", "#27b46a", "#e0409a"];   // blue / green / pink / orange / grey clusters
const HUB_GOLD = "#e0aa22", HUB_PURPLE = "#7c4fe0";
let userInteracted = false, pendingSpeech = null, listenLang = "en-US";

/* ---------- status ---------- */
function setStatus(s) { $("pill").dataset.s = s; $("pilltxt").textContent = s; }
function toast(msg, ms = 3500) { const t = $("toast"); t.textContent = msg; t.style.display = "block"; clearTimeout(toast.t); toast.t = setTimeout(() => (t.style.display = "none"), ms); }
if (MUTE) $("mutetag").style.display = "inline";

/* ---------- galaxy ---------- */
const groups = [...new Set(GRAPH.nodes.map((n) => n.group))];
const gcolor = (g) => PALETTE[Math.max(0, groups.indexOf(g)) % PALETTE.length];
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const data = { nodes: GRAPH.nodes.map((n) => ({ ...n })), links: GRAPH.links.map((l) => ({ ...l })) };
const byId = (i) => data.nodes.find((n) => n.id === i);
const lit = { set: null, pulse: new Set() };
const deg = () => { const d = {}; data.links.forEach((l) => { const a = l.source.id ?? l.source, b = l.target.id ?? l.target; d[a] = (d[a] || 0) + 1; d[b] = (d[b] || 0) + 1; }); return d; };
const hubRank = () => { const d = deg(), ids = data.nodes.map((n) => n.id).sort((a, b) => (d[b] || 0) - (d[a] || 0)); const m = new Map(); ids.forEach((id, i) => m.set(id, i)); return m; };
let ranks = hubRank();
const baseColor = (n) => { const r = ranks.get(n.id) ?? 99, top = Math.max(3, Math.round(data.nodes.length * 0.1)); return r < top ? (r % 3 === 1 ? HUB_PURPLE : HUB_GOLD) : gcolor(n.group); };
const nodeColor = (n) => lit.pulse.has(n.id) ? "#ffffff" : !lit.set ? baseColor(n) : lit.set.has(n.id) ? baseColor(n) : rgba(baseColor(n), 0.18);
const mixHex = (h1, h2) => { const a = parseInt(h1.slice(1), 16), b = parseInt(h2.slice(1), 16); const c = (s) => (((a >> s) & 255) + ((b >> s) & 255)) >> 1; return "#" + ((1 << 24) | (c(16) << 16) | (c(8) << 8) | c(0)).toString(16).slice(1); };
const linkColor = (l) => {                                // thin colourful lines: the colour of the groups they join (a blend across groups)
  const s = l.source.id !== undefined ? l.source : byId(l.source), g = l.target.id !== undefined ? l.target : byId(l.target);
  const a = s?.id ?? l.source, b = g?.id ?? l.target, col = s && g ? mixHex(gcolor(s.group), gcolor(g.group)) : "#8fb0e6";
  return !lit.set ? "rgba(60,170,110,0.28)" : lit.set.has(a) && lit.set.has(b) ? rgba(col, 0.9) : "rgba(60,170,110,0.04)";
};
const graph = ForceGraph3D({ controlType: "orbit" })($("graph"))
  .backgroundColor("rgba(0,0,0,0)").warmupTicks(200).graphData(data).nodeLabel("label").nodeOpacity(0.95)
  .nodeVal((n) => 0.8 + Math.pow(deg()[n.id] || 0, 1.5) * 0.35).nodeRelSize(2.4).nodeResolution(20).nodeColor(nodeColor).linkColor(linkColor).linkWidth(0.25).linkOpacity(1)
  .onNodeClick((n) => focus.flyTo(n.id));
graph.d3Force("charge").strength(-90).distanceMax(160); graph.d3Force("link").distance(42);
graph.controls().autoRotate = true; graph.controls().autoRotateSpeed = 0.35;
let userMoved = false;                                  // fill the screen once the layout has settled, until the person takes the camera
graph.controls().addEventListener("start", () => { userMoved = true; });
const fit = () => {                                      // own fit: wait for a real layout, then back the camera off to frame every note
  if (userMoved || lit.set || !data.nodes.length || !data.nodes.every((n) => Number.isFinite(n.x))) return;
  const c = { x: 0, y: 0, z: 0 }; data.nodes.forEach((n) => { c.x += n.x / data.nodes.length; c.y += n.y / data.nodes.length; c.z += n.z / data.nodes.length; });
  const rs = data.nodes.map((n) => Math.hypot(n.x - c.x, n.y - c.y, n.z - c.z)).sort((x, y) => x - y), r = rs[Math.floor(rs.length * 0.9)];   // frame 90% of the notes; a stray one may sit outside
  if (r < 30) return;                                    // still bunched at the origin: not laid out yet
  const cam = graph.camera(), fov = (cam.fov * Math.PI) / 180;
  const dist = (r * 1.3) / Math.sin(fov / 2);         // the vertical field of view is the tighter one on a wide screen
  const dir = { x: cam.position.x - c.x, y: cam.position.y - c.y, z: cam.position.z - c.z }, dl = Math.hypot(dir.x, dir.y, dir.z) || 1;
  graph.cameraPosition({ x: c.x + (dir.x / dl) * dist, y: c.y + (dir.y / dl) * dist, z: c.z + (dir.z / dl) * dist }, c, 0);
};
[300, 1500, 4000, 9000].forEach((ms) => setTimeout(fit, ms)); graph.onEngineStop(fit);
const refresh = () => { ranks = hubRank(); graph.nodeColor(nodeColor).linkColor(linkColor); };
const neighbours = (i) => { const s = new Set(); data.links.forEach((l) => { const a = l.source.id ?? l.source, b = l.target.id ?? l.target; if (a === i) s.add(b); if (b === i) s.add(a); }); return s; };
$("count").textContent = `${GRAPH.nodes.length} notes · ${groups.length} groups`;


/* ---------- note titles: HTML labels follow the points (crisp Bengali, no 3D text) ---------- */
const labelEls = new Map();
function drawLabels() {
  const box = $("labels"), cam = graph.camera(), cp = cam.position, H = innerHeight, W = innerWidth;
  const hidden = $("workshop").classList.contains("open");
  box.style.display = hidden ? "none" : "block";
  if (!hidden) {
    let near = 1e9, far = 0;
    const ds = data.nodes.map((n) => { const d = Math.hypot((n.x || 0) - cp.x, (n.y || 0) - cp.y, (n.z || 0) - cp.z); near = Math.min(near, d); far = Math.max(far, d); return d; });
    const dg = deg(), taken = [], order = data.nodes.map((n, k) => k).sort((a, b) => (dg[data.nodes[b].id] || 0) - (dg[data.nodes[a].id] || 0) || ds[a] - ds[b]), show = new Set();
    order.slice(0, Math.max(6, Math.round(order.length * 0.14))).forEach((k) => { const n = data.nodes[k], p = graph.graph2ScreenCoords(n.x || 0, n.y || 0, n.z || 0), w = (n.label.length * 6.2 + 12), box_ = [p.x - 4, p.y - 14, p.x + w, p.y + 6];
      if (taken.some((q) => box_[0] < q[2] && box_[2] > q[0] && box_[1] < q[3] && box_[3] > q[1]) && !(lit.set && lit.set.has(n.id))) return;
      taken.push(box_); show.add(k); });
    data.nodes.forEach((n, k) => {
      let el = labelEls.get(n.id);
      if (!el) { el = document.createElement("div"); el.className = "nl"; el.textContent = n.label; box.appendChild(el); labelEls.set(n.id, el); }
      const p = graph.graph2ScreenCoords(n.x || 0, n.y || 0, n.z || 0);
      const e = cam.matrixWorldInverse.elements, zv = e[2] * (n.x || 0) + e[6] * (n.y || 0) + e[10] * (n.z || 0) + e[14];
      const behind = zv > 0 || p.x < -50 || p.x > W + 50 || p.y < -20 || p.y > H + 20;
      const depth = far > near ? 1 - (ds[k] - near) / (far - near) : 1;           // nearer = clearer
      const off = lit.set && !lit.set.has(n.id);
      el.classList.toggle("dim", !!off);
      el.style.opacity = behind || !show.has(k) ? 0 : String(off ? 0.25 : 0.35 + 0.65 * depth);
      el.style.transform = `translate(${Math.round(p.x)}px,${Math.round(p.y) - 8}px)`;
    });
  }
  requestAnimationFrame(drawLabels);
}
requestAnimationFrame(drawLabels);

/* ---------- the voice orb: a raw-WebGL iridescent sphere that mirrors Allaya's state (idle breathes, listening swells, thinking swirls, speaking pulses) ---------- */
(function orb() {
  const cv = $("orbc"), gl = cv.getContext("webgl", { alpha: true, premultipliedAlpha: true, antialias: true });
  if (!gl) { $("orb").style.display = "none"; return; }
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const vs = "attribute vec2 p;varying vec2 v;void main(){v=p;gl_Position=vec4(p,0.,1.);}";
  const fs = `precision highp float;varying vec2 v;uniform float t,e,sw,mx,my;
  float h(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
  float n(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
    return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),
               mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z);}
  void main(){
    vec2 q=v*1.12; float r=length(q);
    float R=.86+.035*sin(t*1.57)*(1.-sw*.4)+e*.05;            // breathing: 4s sine
    if(r>R+.14){gl_FragColor=vec4(0.);return;}
    float z=sqrt(max(R*R-r*r,0.)); vec3 N=normalize(vec3(q,z));
    vec3 P=N*1.6+vec3(0.,0.,t*(.25+sw*.9));
    float d=n(P*1.2+t*.2)*.6+n(P*2.4-t*.3)*.4;                // soft noise displacement
    N=normalize(N+(d-.5)*(.25+e*.35));
    N.xy+=vec2(mx,my)*.18;                                     // leans toward the pointer
    float fr=pow(1.-max(N.z,0.),2.2);
    vec3 A=vec3(.486,.361,1.),B=vec3(.208,.878,1.),C=vec3(1.,.478,.851),D=vec3(1.,.78,.27),E=vec3(.25,.95,.55),F=vec3(1.,.42,.25);
    float film=.5+.5*sin(6.2831*(d*1.4+fr*.9+t*.05)+vec3(0.,2.1,4.2)).x;
    vec3 col=mix(mix(A,B,smoothstep(.2,.8,d+N.x*.35)),C,smoothstep(.45,1.,fr+film*.35));
    col=mix(col,mix(D,E,.5+.5*sin(t*.4+N.y*3.)),smoothstep(.55,.85,n(P*1.8+vec3(t*.15,0.,0.)))*.7);
    col=mix(col,F,smoothstep(.62,.95,n(P*2.6-t*.2))*.5);
    col*=.55+.5*max(N.z,0.)+.5*fr; col+=pow(max(dot(N,normalize(vec3(-.4,.6,.7))),0.),28.)*.35;
    float a=smoothstep(R,R-.02,r);                             // crisp edge
    float halo=smoothstep(R+.14,R,r)*(.18+e*.3)*(1.-a);        // faint glow outside
    gl_FragColor=vec4(col*a+B*halo,max(a,halo));
  }`;
  const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
  const pr = gl.createProgram(); gl.attachShader(pr, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(pr, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) { $("orb").style.display = "none"; return; }
  gl.useProgram(pr);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer()); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(pr, "p"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = Object.fromEntries(["t", "e", "sw", "mx", "my"].map((k) => [k, gl.getUniformLocation(pr, k)]));
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.clearColor(0, 0, 0, 0);
  let e = 0, sw = 0, mx = 0, my = 0, tx = 0, ty = 0, visible = true;
  addEventListener("pointermove", (ev) => { const b = cv.getBoundingClientRect(); tx = Math.max(-1, Math.min(1, (ev.clientX - b.left - b.width / 2) / 400)); ty = Math.max(-1, Math.min(1, -(ev.clientY - b.top - b.height / 2) / 400)); });
  new IntersectionObserver((es) => { visible = es[0].isIntersecting; }).observe(cv);
  const GOAL = { idle: [0, 0], listening: [.55, 0], thinking: [.3, 1], speaking: [.8, .35] };           // [energy, swirl]
  const t0 = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    if (!visible || document.hidden) return;                                                           // pause off-screen
    const s = $("pill").dataset.s || "idle", g = GOAL[s] || GOAL.idle, t = (now - t0) / 1000;
    const pulse = s === "speaking" ? .5 + .5 * Math.sin(t * 9) * Math.sin(t * 2.3) : s === "listening" ? .5 + .5 * Math.sin(t * 3) : 1;
    e += (g[0] * (s === "speaking" || s === "listening" ? .6 + .4 * pulse : 1) - e) * .08; sw += (g[1] - sw) * .05; mx += (tx - mx) * .06; my += (ty - my) * .06;
    gl.viewport(0, 0, cv.width, cv.height); gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(U.t, REDUCED ? 0 : t); gl.uniform1f(U.e, REDUCED ? 0 : e); gl.uniform1f(U.sw, REDUCED ? 0 : sw); gl.uniform1f(U.mx, REDUCED ? 0 : mx); gl.uniform1f(U.my, REDUCED ? 0 : my);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    const tag = { idle: "tap to talk", listening: "listening", thinking: "thinking", speaking: "speaking" }[s]; if ($("orbtag").textContent !== tag) $("orbtag").textContent = tag;
  }
  requestAnimationFrame(frame);
  $("orb").onclick = () => $("mic").click();
})();

/* ---------- ONE OWNER FOR FOCUS: only the answer path (and addNote) goes through this ---------- */
const focus = {
  flyTo(i) {
    const n = byId(i); if (!n) return;
    graph.controls().autoRotate = false;
    const d = 110, r = 1 + d / Math.max(1, Math.hypot(n.x || 1, n.y || 1, n.z || 1));
    graph.cameraPosition({ x: (n.x || 1) * r, y: (n.y || 1) * r, z: (n.z || 1) * r }, n, 1200);
    this.light([i, ...neighbours(i)]); openPanel(i);
  },
  light(idxs) { lit.set = new Set(idxs); refresh(); },
  lightCluster(idxs) { graph.controls().autoRotate = false; this.light(idxs); },
  hold() { /* small talk: touch nothing */ },
  clear() { lit.set = null; refresh(); graph.controls().autoRotate = true; },
};
function openPanel(i) {
  const n = byId(i); if (!n) return;
  $("ptitle").textContent = n.label; $("pmeta").textContent = n.group; $("pbody").textContent = n.excerpt;
  $("plinks").replaceChildren(...[...neighbours(i)].map((j) => chip(byId(j)?.label, () => focus.flyTo(j))));
  // note window removed by request: the panel is never opened
}
function chip(text, fn) { const b = document.createElement("button"); b.className = "chip"; b.textContent = text; b.onclick = fn; return b; }
$("panelx").onclick = () => { $("panel").classList.remove("open"); focus.clear(); };

/* ---------- ONE DOOR FOR NEW NOTES (viewer side) ---------- */
function addNote(node, links) {
  const rel = links.length ? byId(links[0][0]) : null;
  const j = () => (Math.random() - 0.5) * 20;
  const nn = { ...node, x: (rel?.x || 0) + j(), y: (rel?.y || 0) + j(), z: (rel?.z || 0) + j() };
  data.nodes.push(nn); links.forEach(([a, b]) => data.links.push({ source: a, target: b }));
  graph.graphData({ nodes: data.nodes, links: data.links });
  GRAPH.nodes.push(node);
  $("count").textContent = `${data.nodes.length} notes · ${groups.length} groups`;
  lit.pulse.add(node.id); refresh(); setTimeout(() => { lit.pulse.delete(node.id); refresh(); }, 1400);
  setTimeout(() => focus.flyTo(node.id), 700);
}

/* ---------- voice out (the ONE function that speaks) ---------- */
const FEMALE = /female|zira|heera|neerja|nabanita|tanishaa|aria|jenny|sonia|libby|hazel|susan|samantha|natasha|swara|google uk english female/i;
function pickVoice(l) {
  const vs = speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith(l));
  return vs.find((v) => FEMALE.test(v.name)) || vs[0] || null;
}
const hasBengali = () => !!pickVoice("bn");
let VOICE = false, ttsSeq = 0, ttsBusy = false, audioEl = null, ttsWarned = false;
const speaking = () => ttsBusy || !!(audioEl && !audioEl.paused && !audioEl.ended) || speechSynthesis.speaking;
function stopSpeech() { ttsSeq++; ttsBusy = false; if (audioEl) { audioEl.pause(); audioEl = null; } speechSynthesis.cancel(); }
function browserSpeak(text, l) {
  if (!("speechSynthesis" in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  const v = pickVoice(l); if (v) u.voice = v;
  u.lang = v ? v.lang : l === "bn" ? "bn-BD" : "en-GB";
  u.pitch = 1.08; u.rate = 0.98;
  u.onstart = () => setStatus("speaking"); u.onend = () => setStatus("idle"); u.onerror = () => setStatus("idle");
  speechSynthesis.speak(u);
  if (l === "bn" && !hasBengali()) toast("No Bengali voice installed. Add the Bengali language pack in Windows, or use Edge.", 6000);
}
function speechChunks(text) {                               // first chunk is short so audio starts early; the rest is fetched in parallel
  const s = text.match(/[^.!?।]+[.!?।]*\s*/g) || [text]; let first = "", k = 0;
  while (k < s.length && first.length < 60) first += s[k++];
  const rest = s.slice(k).join("").trim();
  return rest ? [first.trim(), rest] : [first.trim()];
}
async function geminiSpeak(text, l, my) {
  ttsBusy = true; const parts = speechChunks(text); let done = 0;
  const reqs = parts.map((t) => api("/speak", { text: t, lang: l }).catch((e) => ({ ok: false, json: { error: e.message } })));
  try {
    for (; done < reqs.length; done++) {
      const { ok, json } = await reqs[done];
      if (my !== ttsSeq) return;                              // a newer sentence (or stop) won; drop this one
      if (!ok) throw new Error(json.error || "voice failed");
      await new Promise((res, rej) => {
        const au = new Audio(json.audio); audioEl = au;
        au.onplay = () => setStatus("speaking"); au.onended = res; au.onerror = () => rej(new Error("audio error")); au.play().catch(rej);
      });
      if (my !== ttsSeq) return;
    }
    ttsBusy = false; setStatus("idle");
  } catch (e) {
    if (my !== ttsSeq) return;
    ttsBusy = false;
    if (!ttsWarned) { ttsWarned = true; toast("Gemini voice unavailable (" + String(e.message).slice(0, 80) + "). Using the browser voice.", 6000); }
    browserSpeak(parts.slice(done).join(" "), l);
  }
}
function speak(text, lang) {
  if (MUTE) return;                                         // mute guard lives here, nowhere else
  if (!userInteracted) { pendingSpeech = [text, lang]; return; }
  const l = lang || (/[ঀ-৿]/.test(text) ? "bn" : "en");
  stopSpeech();
  if (VOICE) geminiSpeak(text, l, ttsSeq); else browserSpeak(text, l);
}
function firstInteraction() { if (userInteracted) return; userInteracted = true; if (pendingSpeech) { speak(...pendingSpeech); pendingSpeech = null; } }
addEventListener("pointerdown", firstInteraction); addEventListener("keydown", firstInteraction);
speechSynthesis?.addEventListener?.("voiceschanged", () => {});

/* ---------- caption + chat ---------- */
const TLIM = 5;
const follow = () => { const l = $("tlist"), w = $("transcript").clientWidth; l.style.transform = `translateX(${-Math.max(0, l.scrollWidth - w)}px)`; };
function trimT() { const l = $("tlist"); while (l.children.length > TLIM) l.firstChild.remove(); [...l.children].forEach((el, i, all) => el.classList.toggle("old", i < all.length - 1)); follow(); }
function tuser(text, live) {                                   // what the person said or typed, shown on the right
  const l = $("tlist"); let el = l.querySelector(".u.live");
  if (!el) { el = document.createElement("div"); el.className = "tm u" + (live ? " live" : ""); l.appendChild(el); }
  el.textContent = text; follow(); if (!live) el.classList.remove("live"); trimT();
}
function say(text, nodes = [], lang) {
  const l = $("tlist"), el = document.createElement("div"); el.className = "tm a";
  const tx = document.createElement("span"); tx.className = "tx"; el.appendChild(tx);
  l.querySelectorAll(".u.live").forEach((x) => x.remove());
  l.appendChild(el); trimT();
  say.fin?.(); const chars = [...text]; let i = 0; say.fin = () => { clearInterval(say.ti); tx.textContent = text; el.classList.add("done"); };
  const step = Math.max(1, Math.ceil(chars.length / 140)), ms = Math.max(14, Math.min(34, 2600 / chars.length));
  say.ti = setInterval(() => {                                // typewriter, paced to finish in a few seconds
    i = Math.min(chars.length, i + step); tx.textContent = chars.slice(0, i).join(""); follow();
    if (i >= chars.length) { clearInterval(say.ti); el.classList.add("done");
      if (nodes.length) { const c = document.createElement("div"); c.className = "chips"; c.append(...nodes.map((n) => chip(byId(n)?.label, () => focus.flyTo(n)))); el.appendChild(c); } }
  }, ms);
  speak(text, lang);
}
async function api(path, body) {
  const r = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return { ok: r.ok, json: await r.json() };
}
async function ask(text) {
  setStatus("thinking");
  try {
    const { json } = await api("/chat", { q: text });
    if (json.warn) toast(json.warn, 6000);
    say(json.answer, json.nodes, json.lang);
    if (json.nodes.length >= 4) focus.lightCluster(json.nodes);         // a cluster, not an arbitrary single node
    else if (json.nodes.length) focus.flyTo(json.nodes[0]);
    else focus.hold();                                                  // small talk or not covered: camera stays still
  } catch (e) { say("I can't reach my server just now.", [], "en"); }
  if (!speaking()) setStatus("idle");
}
async function remember(text) {
  setStatus("thinking");
  const { ok, json } = await api("/remember", { text });
  if (ok) { addNote(json.node, json.links); say(json.say, [], null); }
  else say(json.say || "I could not save that.", [], null);             // never fail silently
}

/* ---------- workshop ---------- */
const stage = $("stage"); let stageReady = false, stageWaiters = [], parts = [], building = false, buildCodes = {}, pieceList = [], selectedKey = null;
const toStage = (m) => stage.contentWindow.postMessage(m, "*");
const whenReady = () => new Promise((r) => (stageReady ? r() : stageWaiters.push(r)));
addEventListener("message", (e) => {
  if (e.source !== stage.contentWindow) return;
  const m = e.data || {};
  if (m.evt === "ready") { stageReady = true; stageWaiters.splice(0).forEach((f) => f()); }
  if (m.evt === "part") { const p = parts.find((x) => x.name === m.name); if (p) { p.state = m.ok ? "ready" : "err"; renderParts(); } if (!m.ok) toast(`Part "${m.name}" failed: ${m.error}`); }
  if (m.evt === "photo") developPhoto(m.mode, m.dataUrl);
  if (m.evt === "pieces") { pieceList = m.pieces; renderPieces(); }
  if (m.evt === "select") { selectedKey = m.key; renderPieces(); showCard(m); }
  if (m.evt === "file") queueSave(m.name, m.buffer);

});
function renderParts() {
  $("partlist").replaceChildren(...parts.map((p) => { const d = document.createElement("div"); d.className = "part" + (p.state === "err" ? " err" : ""); d.innerHTML = "<i></i>"; d.append(p.name); return d; }));
  $("wcount").textContent = parts.length ? `${parts.filter((p) => p.state === "ready").length} / ${parts.length}` : "";
}
function openWorkshop() {
  firstInteraction(); $("workshop").classList.add("open");
  if (!stage.src) stage.src = "/stage.html";
}
function closeWorkshop() { $("workshop").classList.remove("open"); }
async function buildModel(key) {
  const m = LIBRARY[key]; openWorkshop(); await whenReady();
  if (building) return; building = true;
  toStage({ cmd: "clear" }); currentBuildId = null; buildCodes = Object.fromEntries(m.parts.map((p) => [p.name, p.code])); parts = m.parts.map((p) => ({ name: p.name, state: "building" })); renderParts();
  $("wempty").style.display = "none"; $("wtitle").textContent = m.title;
  for (let i = 0; i < m.parts.length; i++) {
    toStage({ cmd: "run", name: m.parts[i].name, code: m.parts[i].code });
    $("wprog").style.width = ((i + 1) / m.parts.length) * 100 + "%";
    await new Promise((r) => setTimeout(r, 450));
  }
  setTimeout(() => ($("wprog").style.width = "0"), 800); building = false;
  say(m.done[document.documentElement.dataset.lang === "bn" ? "bn" : "en"], [], document.documentElement.dataset.lang === "bn" ? "bn" : "en");
}

/* ---------- AI builder (Gemini): streams parts; a change replaces parts, never the build ---------- */
let BUILDER = false, currentBuildId = null;
async function buildAI(prompt, change, extra = {}) {
  openWorkshop(); await whenReady();
  if (building) return toast("Still building. One moment.");
  building = true; $("wempty").style.display = "none"; setStatus("thinking");
  if (!change) { toStage({ cmd: "clear" }); parts = []; buildCodes = {}; currentBuildId = null; $("wtitle").textContent = prompt.slice(0, 48); renderParts(); }
  let got = 0, summary = "", info = null;
  if (!change) { $("wsum").classList.add("show", "busy"); $("wskind").textContent = "Designing"; $("wsname").textContent = prompt.slice(0, 40); $("wssum").textContent = "Sketching the parts one by one."; $("wsmeta").replaceChildren(); }
  else $("wsum").classList.add("busy");
  const t0 = performance.now(), tick = setInterval(() => { if (!got) $("wssum").textContent = `Planning the whole object before drawing it · ${Math.round((performance.now() - t0) / 1000)}s`; }, 1000);
  try {
    const r = await fetch("/build", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, mode: change ? "change" : "new", buildId: change ? currentBuildId : null, image: extra.image, look: extra.look }) });
    const reader = r.body.getReader(), dec = new TextDecoder(); let buf = "";
    for (;;) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
        let ev; try { ev = JSON.parse(line); } catch (e) { continue; }           // a malformed line is skipped, never fatal
        if (ev.type === "start") { currentBuildId = ev.buildId; $("wskind").textContent = "Designing · " + ev.model; }
        else if (ev.type === "title") { if (!change) { $("wsname").textContent = ev.title; $("wtitle").textContent = ev.title; } }
        else if (ev.type === "notice") toast(ev.message, 5000);
        else if (ev.type === "part") {
          got++; buildCodes[ev.name] = ev.code; const ex = parts.find((x) => x.name === ev.name);
          if (ex) ex.state = "building"; else parts.push({ name: ev.name, state: "building" });
          renderParts(); toStage({ cmd: "run", name: ev.name, code: ev.code, holo: !!extra.holo });
          $("wprog").style.width = Math.min(95, got * 5) + "%"; $("wssum").textContent = `Drawing: ${ev.label || ev.name} · ${got} part${got > 1 ? "s" : ""} so far`;
        } else if (ev.type === "part_rejected") toast(`Dropped "${ev.name}": ${ev.message}`);
        else if (ev.type === "error") toast(ev.message, 8000);
        else if (ev.type === "done") { summary = ev.summary; info = ev; }
      }
    }
  } catch (e) { toast("Builder failed: " + e.message, 8000); }
  clearInterval(tick); $("wprog").style.width = "100%"; setTimeout(() => ($("wprog").style.width = "0"), 800);
  building = false; setStatus("idle");
  $("wsum").classList.remove("busy");
  if (info) {
    $("wskind").textContent = change ? "Updated" : "Built"; $("wssum").textContent = summary;
    $("wsmeta").replaceChildren(...[`${Object.keys(buildCodes).length} parts`, info.model, `${info.seconds}s`, info.tokens?.out ? `${info.tokens.out} tokens` : null].filter(Boolean).map((t) => chip(t, () => {})));
  } else if (!got) $("wsum").classList.remove("show");
  const bn = /[\u0980-\u09FF]/.test(prompt);
  if (got) say(summary || (bn ? "তৈরি হয়ে গেছে।" : "It's built."), [], bn ? "bn" : "en");
}

/* ---------- THE BENCH: a picture in, a model out (text inside a picture is data, never an instruction) ---------- */
async function shrink(blob) {
  const bmp = await createImageBitmap(blob), k = Math.min(1, 1568 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.85);
}
async function benchImage(blob) {
  if (!BUILDER) return toast("The picture bench needs provider=gemini and a key in config.json.", 6000);
  openWorkshop(); firstInteraction(); setStatus("thinking");
  let url; try { url = await shrink(blob); } catch (e) { return toast("I couldn't read that picture."); }
  $("benchthumb").src = url; $("benchthumb").hidden = false; $("benchtxt").textContent = "Looking…";
  let info;
  try {
    const { ok, json } = await api("/look", { image: url });
    if (!ok) throw new Error(json.error || "look failed");
    info = json;
  } catch (e) { setStatus("idle"); $("benchtxt").textContent = "Drop a picture or floor plan here · press V to paste"; return toast("Look failed: " + e.message, 8000); }
  const bn = document.documentElement.dataset.lang === "bn";
  const cap = bn ? info.caption_bn : info.caption_en;
  $("benchtxt").textContent = `${info.name} · ${info.category}`;
  say(cap || info.name, [], bn ? "bn" : "en");
  if (info.has_text_instructions) toast("Text in the image was read as data, not as instructions.", 6000);
  const plan = info.category === "floor_plan";
  await new Promise((r) => setTimeout(r, 400));
  buildAI(plan ? `Build this floor plan as a 3D model with real walls, doors and windows: ${info.name}` : `Build a 3D model of: ${info.name}`, false, { image: url, look: info, holo: true });
}
async function grabScreen() {
  try {
    const st = await navigator.mediaDevices.getDisplayMedia({ video: true });
    const v = document.createElement("video"); v.srcObject = st; await v.play(); await new Promise((r) => setTimeout(r, 400));
    const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext("2d").drawImage(v, 0, 0);
    st.getTracks().forEach((t) => t.stop());
    c.toBlob((b) => benchImage(b), "image/png");
  } catch (e) { toast("Screen share cancelled."); }
}
$("pick").onclick = () => $("file").click();
$("file").onchange = (e) => { if (e.target.files[0]) benchImage(e.target.files[0]); e.target.value = ""; };
$("share").onclick = grabScreen;
["dragenter", "dragover"].forEach((ev) => addEventListener(ev, (e) => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); document.body.classList.add("dragging"); } }));
["dragleave", "drop"].forEach((ev) => addEventListener(ev, (e) => { if (ev === "dragleave" && e.relatedTarget) return; document.body.classList.remove("dragging"); }));
addEventListener("drop", (e) => { const f = [...(e.dataTransfer?.files || [])].find((f) => f.type.startsWith("image/")); if (f) { e.preventDefault(); benchImage(f); } });
addEventListener("paste", (e) => { const f = [...(e.clipboardData?.files || [])].find((f) => f.type.startsWith("image/")); if (f) { e.preventDefault(); benchImage(f); } });
addEventListener("keydown", async (e) => {
  if (e.key.toLowerCase() !== "v" || e.ctrlKey || e.metaKey || document.activeElement === $("q") || !$("workshop").classList.contains("open")) return;
  try { for (const it of await navigator.clipboard.read()) { const ty = it.types.find((t) => t.startsWith("image/")); if (ty) return benchImage(await it.getType(ty)); } toast("No picture on the clipboard."); }
  catch (err) { toast("Press Ctrl+V to paste a picture."); }
});

/* ---------- Photograph / Miniature: the live model stays the source of truth; Gemini re-makes a still of it ---------- */
let rawShot = null, aiShot = null, photoBusy = false;
function showLightbox(url, cap, raw) { $("photo").src = url; $("dl").href = url; $("lbcap").textContent = cap; $("lbraw").textContent = raw ? "Show AI photo" : "Show raw render"; $("lightbox").classList.add("open"); }
async function developPhoto(mode, rawUrl) {
  if (photoBusy) return; photoBusy = true; rawShot = rawUrl; aiShot = null;
  const bn = document.documentElement.dataset.lang === "bn", mini = mode === "miniature";
  if (!BUILDER) { photoBusy = false; toast("AI photographs need provider=gemini and a key. Showing the raw render."); return showLightbox(rawUrl, "raw render (no AI)", true); }
  setStatus("thinking"); toast(mini ? "Building your miniature…" : "Developing your photograph…", 20000);
  say(bn ? (mini ? "মিনিয়েচার বানাচ্ছি, একটু অপেক্ষা করুন।" : "ছবি তুলছি, একটু অপেক্ষা করুন।") : (mini ? "Crafting your miniature. One moment." : "Developing your photograph. One moment."), [], bn ? "bn" : "en");
  try {
    const { ok, json } = await api("/photograph", { image: rawUrl, mode });
    if (!ok) throw new Error(json.error || "photograph failed");
    aiShot = json.image; $("toast").style.display = "none";
    showLightbox(aiShot, `${mini ? "Miniature" : "Studio photograph"} · ${json.model} · ${json.tokens ?? "?"} tokens`, false);
    say(bn ? "এই নিন আপনার ছবি।" : mini ? "Your miniature, sir. Rather charming." : "Your photograph. Quite the looker.", [], bn ? "bn" : "en");
  } catch (e) { toast("Photograph failed: " + e.message, 9000); showLightbox(rawUrl, "raw render (AI photo failed)", true); }
  photoBusy = false; setStatus("idle");
}
$("lbraw").onclick = () => { const showingRaw = $("photo").src === rawShot; if (showingRaw && aiShot) showLightbox(aiShot, "AI photo", false); else if (rawShot) showLightbox(rawShot, "raw render", true); };

/* ---------- pieces list, label cards, STL downloads ---------- */
function renderPieces() {
  $("piecelist").replaceChildren(...pieceList.map((p) => {
    const d = document.createElement("div"); d.className = "piece" + (p.key === selectedKey ? " sel" : "");
    const s = document.createElement("span"); s.textContent = p.label; s.title = p.part; d.append(s);
    const b = document.createElement("button"); b.textContent = "STL"; b.title = "Export this piece as a print file";
    b.onclick = (e) => { e.stopPropagation(); toStage({ cmd: "export", which: [p.key] }); }; d.append(b);
    d.onmouseenter = () => toStage({ cmd: "hover", key: p.key }); d.onmouseleave = () => toStage({ cmd: "hover", key: null });
    d.onclick = () => toStage({ cmd: "select", key: p.key === selectedKey ? null : p.key });
    return d;
  }));
}
function showCard(m) {
  const c = $("card"); if (!m.key) { c.style.display = "none"; return; }
  c.style.display = "block"; c.innerHTML = ""; const b = document.createElement("b"); b.textContent = m.label; c.append(b, `Part: ${m.part}`);
  const e = document.createElement("button"); e.className = "btn"; e.style.cssText = "display:block;margin-top:6px"; e.textContent = "Export this piece (STL)"; e.onclick = () => toStage({ cmd: "export", which: [m.key] }); c.append(e);
}
const saveQ = []; let saving = false;
function queueSave(name, buf) { saveQ.push([name, buf]); if (!saving) drainSaves(); }
async function drainSaves() {
  saving = true;
  while (saveQ.length) {
    const [name, buf] = saveQ.shift(), a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([buf], { type: "model/stl" })); a.download = name; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000); await new Promise((r) => setTimeout(r, 350));       // one file per piece, one after another
  }
  saving = false;
}
$("wstl").onclick = () => { if (!pieceList.length) return toast("Nothing to export yet."); toast(`Exporting ${pieceList.length} pieces as STL (whole model scaled to 100 mm)…`, 4000); toStage({ cmd: "export", which: "all" }); };

/* ---------- Phase I: questions about the build are answered from its parts, never by touching the camera ---------- */
async function askBuild(text) {
  const bn = /[\u0980-\u09FF]/.test(text), t0 = performance.now();
  const countQ = /(how many|number of|কয়টি|কতগুলো|কয়টা).*(part|piece|অংশ|টুকরো)/i.test(text);
  const listQ = /(what|which|list).*(part|piece)s?\b|কী কী অংশ/i.test(text);
  if (countQ) return say(bn ? `মোট ${pieceList.length}টি অংশ আছে।` : `There are ${pieceList.length} pieces in ${Object.keys(buildCodes).length} parts.`, [], bn ? "bn" : "en");   // instant, no model
  if (listQ) return say((bn ? "অংশগুলো: " : "The pieces: ") + pieceList.slice(0, 10).map((p) => p.label).join(", ") + (pieceList.length > 10 ? "…" : ""), [], bn ? "bn" : "en");
  setStatus("thinking");
  try {
    const { ok, json } = await api("/ask-build", { question: text, parts: Object.entries(buildCodes).map(([name, code]) => ({ name, code })) });
    if (!ok) throw new Error(json.error || "failed");
    say(json.answer, [], json.lang || (bn ? "bn" : "en"));
    console.log(`ask-build answered in ${Math.round(performance.now() - t0)} ms`);
  } catch (e) { say(bn ? "এখন উত্তর দিতে পারছি না।" : "I can't answer that just now.", [], bn ? "bn" : "en"); }
  if (!speaking()) setStatus("idle");
}
$("wsbtn").onclick = openWorkshop; $("wback").onclick = closeWorkshop;
$("wpull").onclick = () => toStage({ cmd: "explode" }); $("wput").onclick = () => toStage({ cmd: "assemble" });
$("wphoto").onclick = () => toStage({ cmd: "photo", mode: "photo" }); $("wmini").onclick = () => toStage({ cmd: "photo", mode: "miniature" }); $("lbx").onclick = () => $("lightbox").classList.remove("open");

/* ---------- VOICE ROUTES: checked BEFORE a sentence goes to the brain. Add new commands here. ---------- */
const TRIGGERS = "remember that|note to self|don'?t let me forget|log this|মনে রেখো|মনে রাখো|মনে রাখবে|মনে রাখুন";
const VOICE_ROUTES = [
  { name: "interrupt", re: /^(stop|wait|থামো|থামুন|দাঁড়াও|দাঁড়ান)$/i, run: () => { stopSpeech(); setStatus("idle"); } },
  { name: "remember", re: new RegExp(`^(?:${TRIGGERS})[\\s,:.]*(.+)$`, "i"), run: (m) => remember(m[1]) },
  { name: "close workshop", re: /^(close (the )?workshop|back to (the )?galaxy|ওয়ার্কশপ বন্ধ)/i, run: closeWorkshop },
  { name: "pull apart", re: /(pull (it )?apart|take it apart|explode|খুলে দেখাও|আলাদা করো)/i, run: () => { openWorkshop(); toStage({ cmd: "explode" }); } },
  { name: "put back", re: /(put it back|assemble|reassemble|জোড়া লাগাও|আবার লাগাও)/i, run: () => toStage({ cmd: "assemble" }) },
  { name: "miniature", re: /(miniature|make a miniature|মিনিয়েচার|ছোট মডেল)/i, run: () => { openWorkshop(); toStage({ cmd: "photo", mode: "miniature" }); } },
  { name: "photograph", re: /(photograph|take a photo|ছবি তোলো|ফটো তোলো)/i, run: () => { openWorkshop(); toStage({ cmd: "photo", mode: "photo" }); } },
  { name: "ask about build", when: () => $("workshop").classList.contains("open") && Object.keys(buildCodes).length > 0,
    re: /(\?\s*$|^(how|what|which|where|why|is|are|does|do|tell me|কত|কয়|কী|কি|কোন|কেন|কোথায়)\b)/i,
    run: (m, text) => { if (/^(can|could|would|will) you\b/i.test(text)) return buildAI(text, true); return askBuild(text); } },
  { name: "change build", when: () => currentBuildId && $("workshop").classList.contains("open"),
    re: /(make (it|the|them|a|an)|change|paint|colou?r|larger|bigger|smaller|taller|shorter|wider|add (a|an|the|some)|remove|delete|replace|move|rotate|বড়|ছোট|রং|বদলা|পাল্টাও|যোগ|সরাও)/i,
    run: (m, text) => buildAI(text, true) },
  { name: "build", re: /(build|make|create)\s+me|বানাও|বানিয়ে দাও|তৈরি করো|workshop|ওয়ার্কশপ/i, run: (m, text) => {
      const key = Object.keys(LIBRARY).find((k) => LIBRARY[k].match.test(text));
      if (key) return buildModel(key);
      if (/^(open )?(the )?(workshop|ওয়ার্কশপ)/i.test(text)) return openWorkshop();
      if (BUILDER) return buildAI(text.replace(/^(please )?(build|make|create) me (a |an )?/i, ""), false);
      say(/[ঀ-৿]/.test(text) ? "এটা আমার তৈরি-করা তালিকায় নেই। ঘড়ি, ড্রোন বা টার্নটেবিল চেষ্টা করুন। যেকোনো কিছু বানাতে Ollama বা API কী লাগবে।"
        : "That one isn't in my built-in library yet. Try a watch movement, a drone or a turntable. Anything else needs Ollama or an API key.", [], null);
    } },
];
async function route(text) {
  text = text.trim(); if (!text) return;
  tuser(text, false);
  document.documentElement.dataset.lang = /[ঀ-৿]/.test(text) ? "bn" : "en";
  for (const r of VOICE_ROUTES) { if (r.when && !r.when()) continue; const m = text.match(r.re); if (m) { await r.run(m, text); return; } }
  ask(text);
}
$("bar").onsubmit = (e) => { e.preventDefault(); firstInteraction(); const t = $("q").value; $("q").value = ""; route(t); };
addEventListener("keydown", (e) => {
  if (e.key === "/" && document.activeElement !== $("q")) { e.preventDefault(); $("q").focus(); }
  if (e.key === "Escape") { toStage({ cmd: "select", key: null }); $("panelx").click(); $("lightbox").classList.remove("open"); }
});

/* ---------- voice in: buffer until a real pause ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null, listening = false, buf = "", timer = null;
const INTERRUPTS = /^(stop|wait|থামো|থামুন|দাঁড়াও|দাঁড়ান)$/i;
function flush() { const t = buf.trim(); buf = ""; $("q").value = ""; $("q").classList.remove("interim"); if (t) route(t); }
function startMic() {
  if (!SR) return toast("Speech recognition needs Chrome or Edge.");
  firstInteraction(); stopSpeech();
  rec = new SR(); rec.lang = listenLang; rec.continuous = true; rec.interimResults = true;
  rec.onresult = (ev) => {
    let interim = "";
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      const r = ev.results[i], t = r[0].transcript;
      if (r.isFinal) {
        if (INTERRUPTS.test(t.trim())) { buf = ""; clearTimeout(timer); route(t.trim()); continue; }   // bypass the buffer
        buf += " " + t; clearTimeout(timer); timer = setTimeout(flush, FINISH_MS);
      } else interim += t;
    }
    $("q").classList.add("interim"); $("q").value = (buf + " " + interim).trim(); if ($("q").value) tuser($("q").value, true);
  };
  rec.onend = () => { if (listening) { try { rec.start(); } catch (e) {} } };
  rec.onerror = (e) => { if (e.error === "not-allowed") { listening = false; $("mic").classList.remove("on"); toast("Microphone permission denied."); } };
  rec.start(); listening = true; $("mic").classList.add("on"); setStatus("listening");
}
function stopMic() { listening = false; $("mic").classList.remove("on"); try { rec.stop(); } catch (e) {} clearTimeout(timer); if (buf.trim()) flush(); setStatus("idle"); }
$("mic").onclick = () => (listening ? stopMic() : startMic());
$("lang").onclick = () => { listenLang = listenLang === "en-US" ? "bn-BD" : "en-US"; $("lang").textContent = listenLang === "en-US" ? "EN" : "বাং"; if (listening) { stopMic(); startMic(); } };
addEventListener("keydown", (e) => { if (e.key.toLowerCase() === "m" && document.activeElement !== $("q")) $("mic").click(); });

/* ---------- boot ---------- */
fetch("/api/status").then((r) => r.json()).then((s) => {
  BUILDER = !!s.builder; VOICE = !!s.voice; $("count").textContent = `${s.count} notes · ${s.groups} groups · ${s.provider}`;
  const g = s.greeting || "হ্যালো আমি আলেয়া কিভাবে সাহায্য করতে পারি?";
  say(g, [], /[ঀ-৿]/.test(g) ? "bn" : "en");
});

/* ---------- the orb can be dragged anywhere; a drag never counts as a tap ---------- */
(function dragOrb() {
  const o = $("orb"); let sx, sy, ox, oy, moved = false, down = false;
  const place = (x, y) => { x = Math.max(0, Math.min(innerWidth - o.offsetWidth, x)); y = Math.max(0, Math.min(innerHeight - o.offsetHeight, y)); o.style.left = x + "px"; o.style.top = y + "px"; o.style.bottom = "auto"; return [x, y]; };
  try { const p = JSON.parse(localStorage.getItem("orbpos") || "null"); if (p) place(p[0], p[1]); } catch (e) {}
  o.addEventListener("pointerdown", (e) => { down = true; moved = false; sx = e.clientX; sy = e.clientY; const b = o.getBoundingClientRect(); ox = b.left; oy = b.top; o.setPointerCapture(e.pointerId); });
  o.addEventListener("pointermove", (e) => { if (!down) return; if (!moved && Math.hypot(e.clientX - sx, e.clientY - sy) < 5) return; moved = true; o.classList.add("drag"); place(ox + e.clientX - sx, oy + e.clientY - sy); });
  o.addEventListener("pointerup", () => { if (!down) return; down = false; o.classList.remove("drag"); if (moved) { try { localStorage.setItem("orbpos", JSON.stringify([parseFloat(o.style.left), parseFloat(o.style.top)])); } catch (e) {} } });
  o.addEventListener("click", (e) => { if (moved) { e.stopImmediatePropagation(); e.preventDefault(); moved = false; } }, true);
})();


/* ---------- 360° panoramas (Photo Sphere Viewer) and mesh cleanup (Open3D on the server) ---------- */
let psv = null;
$("panobtn").onclick = () => $("panofile").click();
$("panofile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  try {
    const { Viewer } = await import("https://cdn.jsdelivr.net/npm/@photo-sphere-viewer/core@5.15.1/index.module.js");
    psv?.destroy(); $("pano").classList.add("open");
    psv = new Viewer({ container: $("panov"), panorama: URL.createObjectURL(f), navbar: ["zoom", "move", "fullscreen"], defaultYaw: 0 });
  } catch (err) { $("pano").classList.remove("open"); toast("360° viewer failed: " + err.message, 7000); }
};
$("panox").onclick = () => { $("pano").classList.remove("open"); psv?.destroy(); psv = null; };
$("meshbtn").onclick = () => $("meshfile").click();
$("meshfile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  toast("Cleaning mesh with Open3D…", 20000);
  try {
    const b64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(",")[1]); r.onerror = rej; r.readAsDataURL(f); });
    const { ok, json } = await api("/mesh-clean", { data: b64, ext: f.name.split(".").pop(), keep: 1 });
    if (!ok) throw new Error(json.error);
    const a = document.createElement("a"); a.href = "data:model/stl;base64," + json.stl; a.download = f.name.replace(/\.[^.]+$/, "") + "-clean.stl"; a.click();
    toast(`Cleaned: ${json.before[1]} → ${json.after[1]} triangles${json.watertight ? ", watertight" : ""}. Downloaded.`, 7000);
  } catch (err) { toast("Mesh clean failed: " + err.message, 8000); }
};
