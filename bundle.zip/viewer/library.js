/* Built-in models: they work with NO API key. Each part is code that runs ONLY inside the sealed stage frame. */
const GEAR = `function gear(r,teeth,h,mat){const g=new THREE.Group();g.add(new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,48),mat));
const tw=2*Math.PI*r/teeth*0.45;for(let i=0;i<teeth;i++){const a=i/teeth*Math.PI*2;const t=new THREE.Mesh(new THREE.BoxGeometry(tw,h,r*0.18),mat);
t.position.set(Math.cos(a)*r*1.07,0,Math.sin(a)*r*1.07);t.rotation.y=Math.PI/2-a;g.add(t);}return g;}`;

const LIBRARY = {
  watch: {
    title: "Mechanical watch movement",
    match: /watch|movement|clock|ঘড়ি/i,
    done: { en: "Your movement is assembled. Quite the little masterpiece, if I may say so.", bn: "আপনার ঘড়ির যন্ত্রটি তৈরি। ছোট্ট একটা শিল্পকর্ম বলা যায়।" },
    parts: [
      { name: "Main plate", code: `W.scale(3.2);W.frame([0,0.4,0],3.4);const m=new THREE.Mesh(new THREE.CylinderGeometry(2.4,2.4,0.14,96),W.metal('brass'));m.position.y=0.07;W.add(m,{explode:[0,-1.6,0],label:'Main plate'});` },
      { name: "Barrel", code: GEAR + `const g=gear(0.95,28,0.2,W.metal('gold'));g.position.set(-0.9,0.3,0.4);W.add(g,{explode:[-1,1.2,0.4],label:'Mainspring barrel'});W.onTick(t=>g.rotation.y=t*0.25);` },
      { name: "Centre wheel", code: GEAR + `const g=gear(0.7,21,0.18,W.metal('steel'));g.position.set(0.55,0.5,0.35);W.add(g,{explode:[0.8,1.8,0.3],label:'Centre wheel'});W.onTick(t=>g.rotation.y=-t*0.25*28/21);` },
      { name: "Third wheel", code: GEAR + `const g=gear(0.5,16,0.16,W.metal('brass'));g.position.set(1.15,0.7,-0.5);W.add(g,{explode:[1.2,2.4,-0.6],label:'Third wheel'});W.onTick(t=>g.rotation.y=t*0.25*28/21*21/16);` },
      { name: "Escape wheel", code: GEAR + `const g=gear(0.38,15,0.12,W.metal('steel'));g.position.set(0.3,0.9,-1.3);W.add(g,{explode:[0.4,3,-1.3],label:'Escape wheel'});W.onTick(t=>g.rotation.y=-t*0.8);` },
      { name: "Balance wheel", code: `const g=new THREE.Group();const ring=new THREE.Mesh(new THREE.TorusGeometry(0.75,0.06,16,64),W.metal('gold'));ring.rotation.x=Math.PI/2;g.add(ring);
for(let i=0;i<3;i++){const s=new THREE.Mesh(new THREE.BoxGeometry(1.5,0.04,0.06),W.metal('gold'));s.rotation.y=i*Math.PI/3;g.add(s);}
g.position.set(-1.1,1.0,-1.0);W.add(g,{explode:[-1.2,3.4,-1],label:'Balance wheel'});W.onTick(t=>g.rotation.y=Math.sin(t*5)*0.9);` },
      { name: "Bridge", code: `const b=new THREE.Mesh(new THREE.BoxGeometry(2.6,0.12,0.6),W.metal('steel'));b.position.set(0,1.3,0.1);b.rotation.y=0.5;W.add(b,{explode:[0,4.4,0],label:'Steel bridge'});
for(const x of [-1.1,1.1]){const sc=new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,0.14,16),W.metal('black'));sc.position.set(x*Math.cos(0.5),1.38,0.1-x*Math.sin(0.5));W.add(sc,{explode:[0,5.2,0],label:'Screw'});}` },
      { name: "Jewels", code: `[[-0.9,0.45,0.4],[0.55,0.62,0.35],[1.15,0.8,-0.5],[0.3,1.0,-1.3]].forEach((p,i)=>{const j=new THREE.Mesh(new THREE.SphereGeometry(0.12,24,16),new THREE.MeshPhysicalMaterial({color:0xc01030,roughness:0.05,transmission:0.6,thickness:0.3}));j.position.set(...p);W.add(j,{explode:[p[0]*0.6,2+i*0.3,p[2]*0.6],label:'Ruby jewel '+(i+1)});});` },
      { name: "Crystal", code: `const d=new THREE.Mesh(new THREE.SphereGeometry(2.6,64,24,0,Math.PI*2,0,Math.PI/4),W.glass());d.position.y=0.5;W.add(d,{explode:[0,6,0],label:'Sapphire crystal'});` },
    ],
  },
  drone: {
    title: "Quadcopter drone",
    match: /drone|quad|ড্রোন/i,
    done: { en: "Drone assembled. Propellers are decorative until you add a pilot.", bn: "ড্রোন তৈরি। চালক না থাকলে প্রপেলারগুলো শুধু শোভা।" },
    parts: [
      { name: "Body", code: `W.scale(3);W.frame([0,0.4,0],3.2);const b=new THREE.Mesh(new THREE.BoxGeometry(1.4,0.4,1.0),W.plastic(0x20252d));b.position.y=0.9;W.add(b,{explode:[0,1.4,0],label:'Body'});
const top=new THREE.Mesh(new THREE.BoxGeometry(1.0,0.12,0.7),W.metal('black'));top.position.y=1.16;W.add(top,{explode:[0,2.8,0],label:'Top cover'});` },
      { name: "Arms", code: `[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([x,z],i)=>{const a=new THREE.Mesh(new THREE.BoxGeometry(2.2,0.1,0.14),W.metal('black'));a.position.set(x*0.9,0.9,z*0.9);a.rotation.y=Math.atan2(-z,x);W.add(a,{explode:[x*1.4,0,z*1.4],label:'Arm '+(i+1)});});` },
      { name: "Motors", code: `[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([x,z],i)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.22,0.3,32),W.metal('copper'));m.position.set(x*1.7,1.0,z*1.7);W.add(m,{explode:[x*2.4,0.4,z*2.4],label:'Motor '+(i+1)});});` },
      { name: "Propellers", code: `[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([x,z],i)=>{const g=new THREE.Group();for(let k=0;k<2;k++){const bl=new THREE.Mesh(new THREE.BoxGeometry(1.5,0.02,0.18),W.plastic(0xdfe5ec));bl.rotation.y=k*Math.PI/2;g.add(bl);}
g.position.set(x*1.7,1.22,z*1.7);W.add(g,{explode:[x*2.8,2.4,z*2.8],label:'Propeller '+(i+1)});W.onTick(t=>g.rotation.y=t*(i%2?30:-30));});` },
      { name: "Camera gimbal", code: `const g=new THREE.Group();const s=new THREE.Mesh(new THREE.SphereGeometry(0.28,32,24),W.plastic(0x15181d));g.add(s);
const l=new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,0.18,24),W.glass());l.rotation.x=Math.PI/2;l.position.z=0.28;g.add(l);g.position.set(0,0.55,0.55);W.add(g,{explode:[0,-1.6,1.2],label:'Camera gimbal'});` },
      { name: "Landing legs", code: `[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([x,z],i)=>{const l=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.04,0.7,12),W.metal('steel'));l.position.set(x*0.55,0.35,z*0.4);W.add(l,{explode:[x*0.8,-1.6,z*0.6],label:'Leg '+(i+1)});});` },
    ],
  },
  turntable: {
    title: "Turntable",
    match: /turntable|record player|টার্নটেবিল|রেকর্ড/i,
    done: { en: "Turntable ready. The record is, naturally, a classic.", bn: "টার্নটেবিল তৈরি। রেকর্ডটা অবশ্যই ক্লাসিক।" },
    parts: [
      { name: "Plinth", code: `W.scale(3.4);W.frame([0,0.4,0],3.6);const p=new THREE.Mesh(new THREE.BoxGeometry(5,0.5,4),W.wood());p.position.y=0.25;W.add(p,{explode:[0,-1.8,0],label:'Wooden plinth'});` },
      { name: "Platter", code: `const p=new THREE.Mesh(new THREE.CylinderGeometry(1.7,1.7,0.18,96),W.metal('steel'));p.position.set(-0.4,0.6,0);W.add(p,{explode:[0,1.2,0],label:'Platter'});W.onTick(t=>p.rotation.y=-t*0.6);` },
      { name: "Record", code: `const g=new THREE.Group();g.add(new THREE.Mesh(new THREE.CylinderGeometry(1.6,1.6,0.04,96),W.plastic(0x050506)));
const lab=new THREE.Mesh(new THREE.CylinderGeometry(0.5,0.5,0.05,48),W.plastic(0xb5452f));g.add(lab);
for(let r=0.7;r<1.55;r+=0.12){const t=new THREE.Mesh(new THREE.TorusGeometry(r,0.006,6,96),W.metal('black'));t.rotation.x=Math.PI/2;t.position.y=0.025;g.add(t);}
g.position.set(-0.4,0.74,0);W.add(g,{explode:[0,2.6,0],label:'Vinyl record'});W.onTick(t=>g.rotation.y=-t*0.6);` },
      { name: "Spindle", code: `const s=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.04,0.3,16),W.metal('chrome'));s.position.set(-0.4,0.9,0);W.add(s,{explode:[0,3.6,0],label:'Spindle'});` },
      { name: "Tonearm", code: `const g=new THREE.Group();const arm=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.04,2.4,16),W.metal('chrome'));arm.rotation.z=Math.PI/2;arm.position.x=-1.2;g.add(arm);
const base=new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.26,0.4,32),W.metal('black'));g.add(base);const head=new THREE.Mesh(new THREE.BoxGeometry(0.3,0.08,0.18),W.metal('black'));head.position.set(-2.4,-0.04,0);g.add(head);
g.position.set(1.8,0.9,-1.2);g.rotation.y=0.6;W.add(g,{explode:[1.4,1.8,-1],label:'Tonearm'});` },
      { name: "Feet", code: `[[-2.2,-1.7],[2.2,-1.7],[-2.2,1.7],[2.2,1.7]].forEach(([x,z],i)=>{const f=new THREE.Mesh(new THREE.CylinderGeometry(0.16,0.2,0.15,24),W.metal('black'));f.position.set(x,-0.07,z);W.add(f,{explode:[x*0.3,-2.6,z*0.3],label:'Foot '+(i+1)});});` },
    ],
  },
};
